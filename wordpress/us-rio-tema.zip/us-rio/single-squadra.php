<?php
/**
 * Dettaglio di una Squadra: rosa dei Giocatori collegati a questa
 * squadra tramite il campo "Squadra" (ACF, relazione), letta davvero dal
 * database di WordPress. Pagina pubblica: mostra solo nome, cognome e
 * ruolo, non dati sensibili.
 */
get_header();
the_post();
$squadra_id = get_the_ID();

$giocatori = get_posts( array(
	'post_type'      => 'giocatore',
	'posts_per_page' => -1,
	'orderby'        => 'title',
	'order'          => 'ASC',
	'meta_query'     => array(
		array(
			'key'   => 'squadra',
			'value' => $squadra_id,
		),
	),
) );
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Squadre &rsaquo; <?php the_title(); ?></p>
		<h1><?php the_title(); ?></h1>
		<p class="view-sub">Rosa e informazioni della categoria.</p>
	</div>
	<div id="rosaContent">
		<?php if ( $giocatori ) : ?>
			<table class="table-preview">
				<tr><th>Giocatore</th><th>Ruolo</th></tr>
				<?php foreach ( $giocatori as $g ) :
					$cognome = get_field( 'cognome', $g->ID );
					$ruolo   = get_field( 'ruolo', $g->ID );
					?>
					<tr>
						<td><?php echo esc_html( $g->post_title . ( $cognome ? ' ' . $cognome : '' ) ); ?></td>
						<td><?php echo esc_html( $ruolo ?: '—' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		<?php else : ?>
			<div class="placeholder-card">
				<strong>Nessun giocatore trovato.</strong> Non ci sono ancora giocatori assegnati a questa squadra.
			</div>
		<?php endif; ?>
	</div>
</div>
<?php get_footer(); ?>
