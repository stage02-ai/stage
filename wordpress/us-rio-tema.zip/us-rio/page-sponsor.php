<?php
/** Template: pagina "Sponsor" (slug: sponsor) */
get_header();
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Società &rsaquo; Sponsor</p>
		<h1>Sponsor</h1>
		<p class="view-sub">Le aziende che sostengono U.S. Rio A.S.D.</p>
	</div>
	<div class="photo-slot photo-slot-chibi">
		<div class="hero-photo-row"><?php usrio_icon_photo(); ?></div>
		<span>Foto con gli sponsor in arrivo</span>
	</div>
	<div class="sponsor-strip">
		<?php for ( $i = 0; $i < 5; $i++ ) : ?>
			<div class="sponsor-box">Logo sponsor</div>
		<?php endfor; ?>
	</div>
	<div class="placeholder-card">
		<strong>🚧 Sezione da completare.</strong> Qui andranno i loghi e i nomi degli sponsor della società, quando forniti.
	</div>
</div>
<?php get_footer(); ?>
