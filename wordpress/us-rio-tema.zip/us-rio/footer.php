</main>

<footer class="footer">
	<p>U.S. Rio A.S.D. &middot; Affiliata Calcio Padova &middot; Progetto stage, modulo Certificati Medici (Fase 1)</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
