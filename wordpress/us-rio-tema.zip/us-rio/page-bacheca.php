<?php
/** Template: pagina "Bacheca" (slug: bacheca) */
get_header();
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Il club</p>
		<h1>Bacheca</h1>
		<p class="view-sub">Notizie, risultati e comunicati della società.</p>
	</div>
	<div class="photo-slot photo-slot-chibi">
		<div class="hero-photo-row"><?php usrio_icon_photo(); ?></div>
		<span>Foto delle giornate di campionato in arrivo</span>
	</div>
	<div class="news-list">
		<div class="news-item">
			<span class="news-date">Notizia di esempio</span>
			<h3>Titolo della notizia</h3>
			<p>Testo di esempio: qui comparirà l'anteprima di una notizia reale della società, con data e breve descrizione.</p>
		</div>
		<div class="news-item">
			<span class="news-date">Notizia di esempio</span>
			<h3>Titolo della notizia</h3>
			<p>Testo di esempio: qui comparirà l'anteprima di una notizia reale della società, con data e breve descrizione.</p>
		</div>
	</div>
	<div class="placeholder-card">
		<strong>🚧 Notizie di esempio.</strong> Questa sezione mostrerà le news reali della società (risultati, comunicati, eventi) man mano che verranno fornite.
	</div>
</div>
<?php get_footer(); ?>
