<?php
/** Template di ripiego, richiesto da WordPress: usato solo se nessun
 * altro template più specifico corrisponde alla pagina richiesta. */
get_header();
if ( have_posts() ) :
	while ( have_posts() ) : the_post();
		?>
		<div class="view-inner">
			<h1><?php the_title(); ?></h1>
			<div class="prose"><?php the_content(); ?></div>
		</div>
		<?php
	endwhile;
else :
	?>
	<div class="view-inner">
		<div class="placeholder-card"><strong>Pagina non trovata.</strong></div>
	</div>
	<?php
endif;
get_footer();
