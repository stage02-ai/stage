<?php
/**
 * Intestazione del sito: stessa struttura grafica del progetto precedente
 * (menu orizzontale fisso, menu a tutto schermo per mobile), ma con link
 * reali alle pagine di WordPress invece del piccolo "router" in JavaScript
 * usato nella versione precedente.
 */
$usrio_user          = wp_get_current_user();
$usrio_logged_in     = is_user_logged_in();
$usrio_role          = $usrio_logged_in && ! empty( $usrio_user->roles ) ? $usrio_user->roles[0] : '';
$usrio_show_area     = in_array( $usrio_role, array( 'giocatore', 'allenatore', 'socio' ), true );
$usrio_role_labels   = array(
	'giocatore'     => 'Giocatore',
	'allenatore'    => 'Allenatore',
	'iscritto'      => 'Iscritto',
	'socio'         => 'Socio',
	'administrator' => 'Amministratore',
);
$usrio_role_label = isset( $usrio_role_labels[ $usrio_role ] ) ? $usrio_role_labels[ $usrio_role ] : $usrio_role;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="topnav">
	<div class="topnav-inner">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/img/logo.png' ); ?>" alt="Stemma U.S. Rio" class="crest">
			<span class="brand-text">
				<span class="brand-name">U.S. Rio</span>
				<span class="brand-sub">A.S.D. &middot; Affiliata Calcio Padova</span>
			</span>
		</a>

		<nav class="menu">
			<a class="menu-item" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
			<a class="menu-item" href="<?php echo esc_url( home_url( '/societa/' ) ); ?>">Società</a>
			<a class="menu-item" href="<?php echo esc_url( get_post_type_archive_link( 'squadra' ) ); ?>">Squadre</a>
			<a class="menu-item" href="<?php echo esc_url( home_url( '/bacheca/' ) ); ?>">Bacheca</a>
			<a class="menu-item" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>">Contatti</a>
			<?php if ( $usrio_show_area ) : ?>
				<a class="menu-item menu-item-personal" href="<?php echo esc_url( home_url( '/area-riservata/' ) ); ?>">La Mia Area</a>
			<?php endif; ?>
		</nav>

		<div class="topnav-actions">
			<?php if ( $usrio_logged_in ) : ?>
				<div class="user-badge">
					<span class="user-badge-avatar"><?php echo esc_html( strtoupper( mb_substr( $usrio_user->display_name, 0, 1 ) ) ); ?></span>
					<span class="user-badge-info">
						<span class="user-badge-name"><?php echo esc_html( $usrio_user->display_name ); ?></span>
						<span class="user-badge-role"><?php echo esc_html( strtoupper( $usrio_role_label ) ); ?></span>
					</span>
					<a class="btn-logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">Esci</a>
				</div>
			<?php else : ?>
				<a class="btn-login" href="<?php echo esc_url( home_url( '/accedi/' ) ); ?>" aria-label="Accedi" title="Accedi">
					<span class="btn-login-icon"><svg viewBox="0 0 24 24" class="icon-user"><circle cx="12" cy="8" r="4"></circle><path d="M4 20c0-4.4 3.6-7 8-7s8 2.6 8 7"></path></svg></span>
					<span class="btn-login-label">Accedi</span>
				</a>
			<?php endif; ?>
		</div>

		<button class="menu-toggle" id="menuToggle" aria-label="Apri menu">
			<span></span><span></span><span></span>
		</button>
	</div>
</header>

<div class="mobile-menu" id="mobileMenu">
	<nav class="mobile-menu-list">
		<a class="mobile-menu-item" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
		<a class="mobile-menu-item" href="<?php echo esc_url( home_url( '/societa/' ) ); ?>">Società</a>
		<a class="mobile-menu-item" href="<?php echo esc_url( get_post_type_archive_link( 'squadra' ) ); ?>">Squadre</a>
		<a class="mobile-menu-item" href="<?php echo esc_url( home_url( '/bacheca/' ) ); ?>">Bacheca</a>
		<a class="mobile-menu-item" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>">Contatti</a>
		<?php if ( $usrio_show_area ) : ?>
			<a class="mobile-menu-item" href="<?php echo esc_url( home_url( '/area-riservata/' ) ); ?>">La Mia Area</a>
		<?php endif; ?>
		<p class="mobile-menu-label">Account</p>
		<div class="mobile-menu-account">
			<?php if ( $usrio_logged_in ) : ?>
				<div class="user-badge">
					<span class="user-badge-avatar"><?php echo esc_html( strtoupper( mb_substr( $usrio_user->display_name, 0, 1 ) ) ); ?></span>
					<span class="user-badge-info">
						<span class="user-badge-name"><?php echo esc_html( $usrio_user->display_name ); ?></span>
						<span class="user-badge-role"><?php echo esc_html( strtoupper( $usrio_role_label ) ); ?></span>
					</span>
					<a class="btn-logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">Esci</a>
				</div>
			<?php else : ?>
				<a class="btn-login" href="<?php echo esc_url( home_url( '/accedi/' ) ); ?>">
					<span class="btn-login-label">Accedi</span>
				</a>
			<?php endif; ?>
		</div>
	</nav>
</div>

<main id="content" class="content">
