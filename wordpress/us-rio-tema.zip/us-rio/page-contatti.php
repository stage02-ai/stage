<?php
/** Template: pagina "Contatti" (slug: contatti) */
get_header();
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Il club</p>
		<h1>Contatti</h1>
		<p class="view-sub">Come mettersi in contatto con la società.</p>
	</div>
	<div class="photo-slot photo-slot-chibi">
		<div class="hero-photo-row"><?php usrio_icon_photo(); ?></div>
		<span>Vi aspettiamo al campo!</span>
	</div>
	<div class="placeholder-card">
		<strong>🚧 Dati da completare.</strong> Qui andranno indirizzo della sede/campo sportivo, email, telefono e social ufficiali della società.
	</div>
</div>
<?php get_footer(); ?>
