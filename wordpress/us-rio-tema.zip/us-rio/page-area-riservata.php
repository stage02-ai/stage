<?php
/**
 * "La Mia Area" (slug: area-riservata). Contenuto diverso per profilo:
 * - Giocatore: bacheca della propria squadra e certificato medico (solo
 *   il proprio) — ancora segnaposto, sarà collegato al database in un
 *   prossimo passo;
 * - Allenatore: solo la squadra che il Socio gli ha assegnato dal suo
 *   profilo utente (campo ACF "Squadra assegnata"): niente più bisogno di
 *   far coincidere un'email, ora l'accesso è vero;
 * - Socio: non serve più un pannello "fatto in casa" per aggiungere
 *   responsabili/giocatori — può farlo direttamente dal pannello di
 *   amministrazione di WordPress (Utenti, Squadre, Giocatori), che è già
 *   pensato per questo. Qui gli mostriamo solo le scorciatoie dirette.
 */
get_header();

if ( ! is_user_logged_in() ) {
	?>
	<div class="view-inner">
		<div class="placeholder-card">
			<strong>🚧 Area riservata.</strong> Questa pagina è visibile solo dopo aver effettuato l'accesso con il profilo giusto.
		</div>
	</div>
	<?php
	get_footer();
	return;
}

$user = wp_get_current_user();
$role = ! empty( $user->roles ) ? $user->roles[0] : '';
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Area riservata</p>
		<h1>La Mia Area</h1>

		<?php if ( 'allenatore' === $role ) : ?>
			<p class="view-sub">Ciao <?php echo esc_html( $user->display_name ); ?>, ecco la squadra che alleni.</p>
		<?php elseif ( 'socio' === $role ) : ?>
			<p class="view-sub">Ciao <?php echo esc_html( $user->display_name ); ?>, da qui gestisci squadre, giocatori e accessi al sito.</p>
		<?php else : ?>
			<p class="view-sub">Ciao <?php echo esc_html( $user->display_name ); ?>, scegli cosa vuoi vedere.</p>
		<?php endif; ?>
	</div>

	<?php if ( 'socio' === $role ) : ?>
		<p class="admin-status" id="areaStatus"></p>
	<?php endif; ?>

	<?php if ( 'allenatore' === $role ) :
		$squadra = get_field( 'squadra_assegnata', 'user_' . $user->ID );
		?>
		<div class="showcase-grid">
			<?php if ( $squadra ) : ?>
				<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/bacheca-squadra/?team=' . $squadra->ID ) ); ?>">
					<div class="thumb"><?php usrio_icon_photo(); ?></div>
					<div class="body">
						<span class="name"><?php echo esc_html( $squadra->post_title ); ?></span>
						<span class="desc">Bacheca riservata a questa squadra.</span>
					</div>
				</div>
			<?php else : ?>
				<div class="placeholder-card">
					<strong>🚧 Nessuna squadra assegnata.</strong> Il Socio non ti ha ancora assegnato una squadra dal tuo profilo utente. Chiedigli di farlo da Utenti → il tuo profilo → "Squadra assegnata".
				</div>
			<?php endif; ?>
		</div>

	<?php elseif ( 'socio' === $role ) : ?>
		<div class="admin-section">
			<h2>Squadre</h2>
			<p class="admin-section-desc">Le categorie della società (Prima Squadra, Juniores, ecc.). Rimuovere una squadra non tocca i giocatori già inseriti: restano in rosa, semplicemente senza squadra finché non li sposti.</p>
			<div id="areaSquadreTable"><p class="loading-note">Caricamento…</p></div>
			<form class="admin-form" id="areaSalvaSquadraForm" novalidate>
				<label class="form-group">
					<span>Nome squadra</span>
					<input type="text" id="areaSquadraNome" placeholder="Es. Allievi">
				</label>
				<p class="form-error" id="areaSquadraError"></p>
				<button type="submit" class="btn-primary">Aggiungi squadra</button>
			</form>
		</div>

		<div class="admin-section">
			<h2>Rosa dei giocatori</h2>
			<p class="admin-section-desc">Aggiungi o rimuovi i giocatori nella rosa di ogni squadra.</p>
			<label class="form-group">
				<span>Squadra</span>
				<select id="areaGiocatoriSquadraSelect"></select>
			</label>
			<div id="areaGiocatoriTable"><p class="loading-note">Caricamento…</p></div>
			<form class="admin-form" id="areaSalvaGiocatoreForm" novalidate>
				<label class="form-group">
					<span>Nome</span>
					<input type="text" id="areaGiocNome" placeholder="Es. Luca">
				</label>
				<label class="form-group">
					<span>Cognome</span>
					<input type="text" id="areaGiocCognome" placeholder="Es. Bianchi">
				</label>
				<label class="form-group">
					<span>Ruolo</span>
					<input type="text" id="areaGiocRuolo" placeholder="Es. Centrocampista">
				</label>
				<p class="form-error" id="areaGiocError"></p>
				<button type="submit" class="btn-primary">Aggiungi giocatore</button>
			</form>
		</div>

		<div class="admin-section">
			<h2>Accessi al sito</h2>
			<p class="admin-section-desc">Crea le credenziali per Giocatori, Allenatori e Iscritti direttamente da qui: la password viene generata e inviata via email, come già succede da wp-admin. Per l'Allenatore scegli subito la squadra da assegnargli; per il Giocatore, la riga di rosa a cui corrisponde (aggiungila prima qui sopra se non c'è ancora).</p>
			<div id="areaUtentiTable"><p class="loading-note">Caricamento…</p></div>
			<form class="admin-form" id="areaCreaUtenteForm" novalidate>
				<label class="form-group">
					<span>Nome</span>
					<input type="text" id="utenteNome" placeholder="Es. Mario">
				</label>
				<label class="form-group">
					<span>Cognome</span>
					<input type="text" id="utenteCognome" placeholder="Es. Rossi">
				</label>
				<label class="form-group">
					<span>Email</span>
					<input type="email" id="utenteEmail" placeholder="nome@esempio.it">
				</label>
				<label class="form-group">
					<span>Profilo</span>
					<select id="utenteRuolo">
						<option value="" selected disabled>Scegli un profilo</option>
						<option value="giocatore">Giocatore</option>
						<option value="allenatore">Allenatore</option>
						<option value="iscritto">Iscritto</option>
					</select>
				</label>
				<label class="form-group" id="utenteSquadraGroup" hidden>
					<span>Squadra da assegnare</span>
					<select id="utenteSquadraSelect"></select>
				</label>
				<label class="form-group" id="utenteGiocatoreGroup" hidden>
					<span>Riga di rosa da collegare</span>
					<select id="utenteGiocatoreSelect"></select>
				</label>
				<p class="form-error" id="areaUtenteError"></p>
				<button type="submit" class="btn-primary">Crea accesso</button>
			</form>
		</div>

		<div class="admin-section">
			<h2>Bacheca squadre</h2>
			<p class="admin-section-desc">Gestisci il calendario di partite, allenamenti e convocazioni di qualsiasi squadra della società: utile anche per correggere o togliere un evento sbagliato.</p>
			<a class="btn-primary usrio-inline-btn" href="<?php echo esc_url( home_url( '/bacheca-squadra/' ) ); ?>">Apri bacheca squadre</a>
		</div>

	<?php else : ?>
		<div class="showcase-grid">
			<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/bacheca-squadra/' ) ); ?>">
				<div class="thumb"><?php usrio_icon_photo(); ?></div>
				<div class="body">
					<span class="name">Bacheca Squadra</span>
					<span class="desc">Avvisi e comunicazioni riservate alla tua squadra.</span>
				</div>
			</div>
			<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/certificato-personale/' ) ); ?>">
				<div class="thumb"><?php usrio_icon_photo(); ?></div>
				<div class="body">
					<span class="name">Certificato Medico</span>
					<span class="desc">Il tuo certificato medico, solo il tuo.</span>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
