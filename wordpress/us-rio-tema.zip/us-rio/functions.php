<?php
/**
 * Funzioni del tema U.S. Rio A.S.D.
 *
 * Qui dentro:
 * - carichiamo la grafica del sito (lo stesso file css/style.css del vecchio progetto);
 * - creiamo i "tipi di contenuto" Squadra e Giocatore, così il Socio può
 *   gestirli dal pannello di WordPress come farebbe con Articoli o Pagine;
 * - creiamo i profili di accesso (Giocatore, Allenatore, Iscritto, Socio) come
 *   ruoli utente reali di WordPress, con permessi diversi;
 * - aggiungiamo il campo "Squadra assegnata" al profilo di un Allenatore.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------
// Impostazioni di base del tema
// ---------------------------------------------------------------------
function usrio_theme_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	register_nav_menus( array(
		'primary' => 'Menu principale',
	) );
}
add_action( 'after_setup_theme', 'usrio_theme_setup' );

// Toglie del tutto la barra nera di WordPress in cima alle pagine del
// sito (per chiunque, Socio e Amministratore inclusi): è piena di link
// verso wp-admin ed è il modo più facile per "uscire" dal sito per
// sbaglio. Chi lavora davvero su WordPress ci arriva comunque scrivendo
// l'indirizzo /wp-admin/ a mano.
add_filter( 'show_admin_bar', '__return_false' );

function usrio_enqueue_assets() {
	wp_enqueue_style( 'usrio-google-fonts', 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Public+Sans:wght@400;500;600;700&display=swap', array(), null );
	// Lo stesso foglio di stile del sito costruito nella fase precedente,
	// solo spostato dentro il tema: la grafica resta identica.
	wp_enqueue_style( 'usrio-site', get_template_directory_uri() . '/site-style.css', array(), '1.0' );
	wp_enqueue_style( 'usrio-theme', get_template_directory_uri() . '/theme-extra.css', array( 'usrio-site' ), '1.0' );
	wp_enqueue_script( 'usrio-main', get_template_directory_uri() . '/js/site.js', array(), '1.0', true );

	// Bacheca Squadra: calendario caricato e gestito via AJAX direttamente
	// nel sito (niente wp-admin), solo nella pagina che lo usa davvero.
	if ( is_page( 'bacheca-squadra' ) ) {
		wp_enqueue_script( 'usrio-calendario', get_template_directory_uri() . '/js/bacheca-calendario.js', array(), '1.0', true );
		wp_localize_script( 'usrio-calendario', 'UsrioCalendarioAjax', array(
			'url'   => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'usrio_calendario' ),
		) );
	}

	// Pannello del Socio in "La Mia Area": rosa e accessi (giocatori,
	// allenatori, iscritti) gestiti via AJAX direttamente nel sito, mai da
	// wp-admin.
	if ( is_page( 'area-riservata' ) ) {
		wp_enqueue_script( 'usrio-area-riservata', get_template_directory_uri() . '/js/area-riservata.js', array(), '1.0', true );
		wp_localize_script( 'usrio-area-riservata', 'UsrioAreaRiservataAjax', array(
			'url'   => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'usrio_area_riservata' ),
		) );
	}
}
add_action( 'wp_enqueue_scripts', 'usrio_enqueue_assets' );

// ---------------------------------------------------------------------
// Tipo di contenuto "Squadra" (le categorie della società: Prima Squadra,
// Juniores, ecc.)
// ---------------------------------------------------------------------
function usrio_register_squadra_cpt() {
	register_post_type( 'squadra', array(
		'labels' => array(
			'name'          => 'Squadre',
			'singular_name' => 'Squadra',
			'add_new_item'  => 'Aggiungi squadra',
			'edit_item'     => 'Modifica squadra',
			'all_items'     => 'Tutte le squadre',
		),
		'public'       => true,
		'has_archive'  => true,
		'rewrite'      => array( 'slug' => 'squadre' ),
		'menu_icon'    => 'dashicons-groups',
		'supports'     => array( 'title', 'thumbnail' ),
		'show_in_rest' => true,
	) );
}
add_action( 'init', 'usrio_register_squadra_cpt' );

// ---------------------------------------------------------------------
// Tipo di contenuto "Giocatore" (la rosa di ogni squadra)
// ---------------------------------------------------------------------
function usrio_register_giocatore_cpt() {
	register_post_type( 'giocatore', array(
		'labels' => array(
			'name'          => 'Giocatori',
			'singular_name' => 'Giocatore',
			'add_new_item'  => 'Aggiungi giocatore',
			'edit_item'     => 'Modifica giocatore',
			'all_items'     => 'Tutti i giocatori',
		),
		'public'       => true,
		'has_archive'  => false,
		'rewrite'      => array( 'slug' => 'giocatori' ),
		'menu_icon'    => 'dashicons-id',
		'supports'     => array( 'title', 'thumbnail' ),
		'show_in_rest' => true,
	) );
}
add_action( 'init', 'usrio_register_giocatore_cpt' );

// ---------------------------------------------------------------------
// Tipo di contenuto "Evento" (partite e allenamenti della Bacheca
// Squadra). Non pubblico (non ha una pagina propria: viene letto e
// mostrato dal template page-bacheca-squadra.php come un calendario
// mensile), con un tipo di permessi tutto suo ('evento'/'eventi') invece
// di quello standard degli Articoli: così si può dare all'Allenatore la
// possibilità di gestire i propri eventi senza per questo dargli anche
// accesso a Squadre, Giocatori o Articoli.
// ---------------------------------------------------------------------
function usrio_register_evento_cpt() {
	register_post_type( 'evento', array(
		'labels' => array(
			'name'          => 'Bacheca Squadra',
			'singular_name' => 'Evento',
			'add_new_item'  => 'Aggiungi partita/allenamento',
			'edit_item'     => 'Modifica evento',
			'all_items'     => 'Calendario eventi',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-calendar-alt',
		'supports'        => array(), // Il titolo viene generato da solo dai dati dell'evento: vedi usrio_set_evento_title().
		'capability_type' => array( 'evento', 'eventi' ),
		'map_meta_cap'    => true,
	) );
}
add_action( 'init', 'usrio_register_evento_cpt' );

// Genera il titolo dell'evento (es. "Partita vs Juniores - Prima Squadra -
// 15/09/2026") dai suoi campi: così chi lo crea non deve scrivere un
// titolo a mano, e l'elenco in wp-admin resta comunque leggibile. Usata
// sia quando l'evento viene salvato da wp-admin (via il gancio più sotto),
// sia dalla Bacheca Squadra sul sito (vedi usrio_ajax_salva_evento).
function usrio_generate_evento_title( $post_id ) {
	$tipo           = get_field( 'tipo_evento', $post_id );
	$data           = get_field( 'data_evento', $post_id );
	$squadra        = get_field( 'squadra_evento', $post_id );
	$nome_squadra   = $squadra ? get_the_title( $squadra ) : 'Squadra';
	$data_leggibile = $data ? date_i18n( 'd/m/Y', strtotime( $data ) ) : '';

	if ( 'partita' === $tipo ) {
		$avversario = get_field( 'avversario_evento', $post_id );
		return 'Partita' . ( $avversario ? ' vs ' . $avversario : '' ) . ' - ' . $nome_squadra . ' - ' . $data_leggibile;
	}
	return 'Allenamento - ' . $nome_squadra . ' - ' . $data_leggibile;
}

function usrio_set_evento_title( $post_id ) {
	if ( get_post_type( $post_id ) !== 'evento' ) {
		return;
	}
	remove_action( 'acf/save_post', 'usrio_set_evento_title', 20 );
	wp_update_post( array( 'ID' => $post_id, 'post_title' => usrio_generate_evento_title( $post_id ) ) );
	add_action( 'acf/save_post', 'usrio_set_evento_title', 20 );
}
add_action( 'acf/save_post', 'usrio_set_evento_title', 20 );

// ---------------------------------------------------------------------
// Campi personalizzati (ACF), creati da codice: così non serve
// configurarli a mano dal pannello, e restano documentati qui.
// ---------------------------------------------------------------------
function usrio_register_acf_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	// Campi del Giocatore: cognome, ruolo, e a quale Squadra appartiene.
	acf_add_local_field_group( array(
		'key'    => 'group_giocatore',
		'title'  => 'Dati giocatore',
		'fields' => array(
			array(
				'key'   => 'field_giocatore_cognome',
				'label' => 'Cognome',
				'name'  => 'cognome',
				'type'  => 'text',
			),
			array(
				'key'   => 'field_giocatore_ruolo',
				'label' => 'Ruolo',
				'name'  => 'ruolo',
				'type'  => 'text',
			),
			array(
				'key'           => 'field_giocatore_squadra',
				'label'         => 'Squadra',
				'name'          => 'squadra',
				'type'          => 'post_object',
				'post_type'     => array( 'squadra' ),
				'return_format' => 'object',
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'giocatore',
				),
			),
		),
	) );

	// Campo sul profilo utente: a quale Squadra è assegnato un Allenatore
	// (il Socio lo imposta quando crea o modifica l'utente). Da questo
	// dipende quali squadre l'allenatore vede nella sua Area riservata.
	acf_add_local_field_group( array(
		'key'    => 'group_allenatore_squadra',
		'title'  => 'Squadra assegnata (Allenatore)',
		'fields' => array(
			array(
				'key'           => 'field_utente_squadra',
				'label'         => 'Squadra assegnata',
				'name'          => 'squadra_assegnata',
				'type'          => 'post_object',
				'post_type'     => array( 'squadra' ),
				'return_format' => 'object',
				'instructions'  => 'Visibile e utile solo per il profilo Allenatore: determina quale squadra vede nella sua Area riservata.',
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'user_form',
					'operator' => '==',
					'value'    => 'edit',
				),
			),
		),
	) );

	// Campo sul profilo utente: a quale riga della rosa (Giocatore)
	// corrisponde l'accesso di un Giocatore (il Socio lo imposta quando crea
	// o modifica l'utente, scegliendo il suo nome tra i Giocatori già
	// inseriti). Da questo dipende quale squadra vede nella sua Area
	// riservata: senza questo collegamento non deve poter scegliere lui una
	// squadra qualsiasi, altrimenti vedrebbe anche le bacheche di squadre
	// che non sono la sua.
	acf_add_local_field_group( array(
		'key'    => 'group_giocatore_utente',
		'title'  => 'Giocatore collegato (Giocatore)',
		'fields' => array(
			array(
				'key'           => 'field_utente_giocatore',
				'label'         => 'Giocatore collegato',
				'name'          => 'giocatore_collegato',
				'type'          => 'post_object',
				'post_type'     => array( 'giocatore' ),
				'return_format' => 'object',
				'instructions'  => 'Visibile e utile solo per il profilo Giocatore: scegli a quale riga della rosa corrisponde, così vedrà nella sua Area riservata la bacheca della squadra giusta (e nessun\'altra).',
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'user_form',
					'operator' => '==',
					'value'    => 'edit',
				),
			),
		),
	) );

	// Campi dell'Evento (partita o allenamento) della Bacheca Squadra: i
	// campi mostrati cambiano in base al Tipo scelto (avversario e
	// casa/trasferta solo per una partita; nota solo per un allenamento).
	acf_add_local_field_group( array(
		'key'    => 'group_evento',
		'title'  => 'Dettagli evento',
		'fields' => array(
			array(
				'key'           => 'field_evento_tipo',
				'label'         => 'Tipo',
				'name'          => 'tipo_evento',
				'type'          => 'select',
				'choices'       => array(
					'partita'     => 'Partita',
					'allenamento' => 'Allenamento',
				),
				'default_value' => 'partita',
				'required'      => 1,
			),
			array(
				'key'           => 'field_evento_squadra',
				'label'         => 'Squadra',
				'name'          => 'squadra_evento',
				'type'          => 'post_object',
				'post_type'     => array( 'squadra' ),
				'return_format' => 'object',
				'required'      => 1,
				'instructions'  => "Scegli la squadra a cui appartiene questo evento: l'Allenatore, in Area riservata, vede solo gli eventi della propria.",
			),
			array(
				'key'            => 'field_evento_data',
				'label'          => 'Data',
				'name'           => 'data_evento',
				'type'           => 'date_picker',
				'display_format' => 'd/m/Y',
				'return_format'  => 'Ymd',
				'required'       => 1,
			),
			array(
				'key'             => 'field_evento_ora',
				'label'           => 'Orario',
				'name'            => 'ora_evento',
				'type'            => 'time_picker',
				'display_format'  => 'H:i',
				'return_format'   => 'H:i',
			),
			array(
				'key'   => 'field_evento_luogo',
				'label' => 'Luogo',
				'name'  => 'luogo_evento',
				'type'  => 'text',
			),
			array(
				'key'               => 'field_evento_avversario',
				'label'             => 'Avversario',
				'name'              => 'avversario_evento',
				'type'              => 'text',
				'conditional_logic' => array(
					array(
						array( 'field' => 'field_evento_tipo', 'operator' => '==', 'value' => 'partita' ),
					),
				),
			),
			array(
				'key'               => 'field_evento_casa_trasferta',
				'label'             => 'Casa o trasferta',
				'name'              => 'casa_trasferta_evento',
				'type'              => 'select',
				'choices'           => array(
					'casa'      => 'Casa',
					'trasferta' => 'Trasferta',
				),
				'default_value'     => 'casa',
				'conditional_logic' => array(
					array(
						array( 'field' => 'field_evento_tipo', 'operator' => '==', 'value' => 'partita' ),
					),
				),
			),
			array(
				'key'               => 'field_evento_note',
				'label'             => 'Note (facoltative)',
				'name'              => 'note_evento',
				'type'              => 'text',
				'conditional_logic' => array(
					array(
						array( 'field' => 'field_evento_tipo', 'operator' => '==', 'value' => 'allenamento' ),
					),
				),
			),
			array(
				'key'               => 'field_evento_convocati',
				'label'             => 'Convocati',
				'name'              => 'convocati_evento',
				'type'              => 'relationship',
				'post_type'         => array( 'giocatore' ),
				'filters'           => array( 'search' ),
				'return_format'     => 'object',
				'instructions'      => 'Scegli qui i giocatori convocati per questa partita, tra quelli della squadra scelta sopra (il campo elenca tutti i giocatori: scegli con attenzione quelli della squadra giusta).',
				'conditional_logic' => array(
					array(
						array( 'field' => 'field_evento_tipo', 'operator' => '==', 'value' => 'partita' ),
					),
				),
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'evento',
				),
			),
		),
	) );
}
add_action( 'acf/init', 'usrio_register_acf_fields' );

// ---------------------------------------------------------------------
// Profili di accesso (ruoli utente): Giocatore, Allenatore, Iscritto,
// Socio. Il Socio è l'amministratore "gestionale" del sito: può
// aggiungere/rimuovere responsabili (utenti Allenatore) e giocatori, ma
// non tocca le impostazioni tecniche del sito riservate all'Amministratore
// vero e proprio.
// ---------------------------------------------------------------------
function usrio_register_roles() {
	if ( ! get_role( 'giocatore' ) ) {
		add_role( 'giocatore', 'Giocatore', array( 'read' => true ) );
	}
	if ( ! get_role( 'allenatore' ) ) {
		add_role( 'allenatore', 'Allenatore', array( 'read' => true ) );
	}
	if ( ! get_role( 'iscritto' ) ) {
		add_role( 'iscritto', 'Iscritto', array( 'read' => true ) );
	}

	$socio = get_role( 'socio' );
	if ( ! $socio ) {
		add_role( 'socio', 'Socio', array( 'read' => true ) );
		$socio = get_role( 'socio' );
	}
	// Il Socio può gestire (creare/modificare/eliminare) Squadre e
	// Giocatori, e può creare/gestire utenti Allenatore — ma non ha i
	// permessi di amministrazione tecnica del sito (temi, plugin, ecc.).
	if ( $socio ) {
		$capabilities = array(
			'read'                   => true,
			'edit_posts'             => true,
			'edit_others_posts'      => true,
			'edit_published_posts'   => true,
			'publish_posts'          => true,
			'delete_posts'           => true,
			'delete_others_posts'    => true,
			'delete_published_posts' => true,
			'upload_files'           => true,
			'list_users'             => true,
			'create_users'           => true,
			'edit_users'             => true,
			'delete_users'           => true,
			'promote_users'          => true,
		);
		foreach ( $capabilities as $cap => $grant ) {
			$socio->add_cap( $cap, $grant );
		}
	}

	// Permessi sul tipo di contenuto "Evento" (partite e allenamenti):
	// Socio e Amministratore gestiscono gli eventi di tutte le squadre;
	// l'Allenatore gestisce solo quelli che crea lui (niente "_others_":
	// WordPress mostra e permette di modificare solo i propri, di serie,
	// senza bisogno di altro codice).
	$evento_caps_tutti = array(
		'edit_evento', 'read_evento', 'delete_evento',
		'edit_eventi', 'edit_others_eventi', 'edit_private_eventi', 'edit_published_eventi',
		'publish_eventi', 'read_private_eventi',
		'delete_eventi', 'delete_private_eventi', 'delete_published_eventi', 'delete_others_eventi',
	);
	$evento_caps_proprio = array(
		'edit_evento', 'read_evento', 'delete_evento',
		'edit_eventi', 'edit_published_eventi', 'publish_eventi',
		'delete_eventi', 'delete_published_eventi',
	);

	if ( $socio ) {
		foreach ( $evento_caps_tutti as $cap ) {
			$socio->add_cap( $cap, true );
		}
	}

	// L'Amministratore di WordPress non riceve automaticamente i permessi
	// di un tipo di contenuto con permessi propri come questo: vanno
	// aggiunti a mano, altrimenti non vedrebbe "Bacheca Squadra" nel menu.
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		foreach ( $evento_caps_tutti as $cap ) {
			$admin->add_cap( $cap, true );
		}
	}

	$allenatore = get_role( 'allenatore' );
	if ( $allenatore ) {
		foreach ( $evento_caps_proprio as $cap ) {
			$allenatore->add_cap( $cap, true );
		}
	}
}
add_action( 'init', 'usrio_register_roles' );

// Il Socio deve poter assegnare solo i profili di questo sito (non può
// promuovere sé stesso/altri ad Amministratore): l'elenco dei ruoli che
// vede nel modulo "Aggiungi utente" è limitato.
function usrio_limit_role_choices( $roles ) {
	if ( current_user_can( 'administrator' ) ) {
		return $roles;
	}
	$allowed = array( 'giocatore', 'allenatore', 'iscritto', 'socio' );
	return array_intersect_key( $roles, array_flip( $allowed ) );
}
add_filter( 'editable_roles', 'usrio_limit_role_choices' );

// ---------------------------------------------------------------------
// Dopo l'accesso, riporta sempre la persona al sito (mai al pannello di
// amministrazione di WordPress, per nessun profilo, Socio incluso): tutta
// la comunicazione con chi visita deve restare dentro il sito, come nella
// versione Node.js. Chi ha davvero bisogno di wp-admin (solo per lavori
// tecnici sul tema/i plugin) ci arriva comunque digitando l'indirizzo a
// mano, ma non ci viene mai portato automaticamente.
// ---------------------------------------------------------------------
function usrio_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
	return home_url( '/' );
}
add_filter( 'login_redirect', 'usrio_login_redirect', 10, 3 );

// ---------------------------------------------------------------------
// Icona "foto" riutilizzata al posto delle mascotte/foto reali, in
// attesa delle immagini vere della società (stessa icona della versione
// precedente del sito).
// ---------------------------------------------------------------------
function usrio_icon_photo() {
	echo '<svg viewBox="0 0 100 100" class="icon-illustration"><rect x="8" y="20" width="84" height="64" rx="8"/><circle cx="34" cy="42" r="9"/><path d="M12 74 L38 48 L56 64 L72 44 L88 62"/></svg>';
}

// ---------------------------------------------------------------------
// Bacheca Squadra via AJAX: la gestione degli eventi (partite,
// allenamenti, convocazioni) avviene direttamente nel sito, nella pagina
// "Bacheca Squadra" — non su wp-admin. Le richieste arrivano dallo script
// js/bacheca-calendario.js, caricato solo su quella pagina.
// ---------------------------------------------------------------------

// Ferma la richiesta se manca l'accesso o il nonce non è valido: usata
// all'inizio di ogni funzione AJAX qui sotto.
function usrio_calendario_verifica_nonce() {
	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'errore' => "Devi effettuare l'accesso." ), 401 );
	}
	check_ajax_referer( 'usrio_calendario', 'nonce' );
}

// Per l'Allenatore, la squadra da usare è sempre e solo quella assegnata
// dal Socio: qualsiasi id arrivi dalla richiesta viene ignorato, così non
// può in nessun modo salvare eventi su una squadra che non è la sua.
function usrio_evento_squadra_consentita( $squadra_id_richiesta ) {
	$user = wp_get_current_user();
	$role = ! empty( $user->roles ) ? $user->roles[0] : '';
	if ( 'allenatore' === $role ) {
		$squadra_assegnata = get_field( 'squadra_assegnata', 'user_' . $user->ID );
		return $squadra_assegnata ? $squadra_assegnata->ID : 0;
	}
	return $squadra_id_richiesta;
}

// Elenco delle squadre della società (per il selettore di Giocatore e Socio).
function usrio_ajax_get_squadre() {
	usrio_calendario_verifica_nonce();
	$squadre = get_posts( array(
		'post_type'      => 'squadra',
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	wp_send_json( array_map( function ( $s ) {
		return array( 'id' => $s->ID, 'nome' => $s->post_title );
	}, $squadre ) );
}
add_action( 'wp_ajax_usrio_get_squadre', 'usrio_ajax_get_squadre' );

// Rosa di una squadra (per le caselle delle convocazioni: sempre i
// giocatori veri, mai nomi a caso).
function usrio_ajax_get_giocatori() {
	usrio_calendario_verifica_nonce();
	$squadra_id = isset( $_REQUEST['squadra_id'] ) ? absint( $_REQUEST['squadra_id'] ) : 0;
	$giocatori  = get_posts( array(
		'post_type'      => 'giocatore',
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
		'meta_query'     => array(
			array( 'key' => 'squadra', 'value' => $squadra_id, 'compare' => '=', 'type' => 'NUMERIC' ),
		),
	) );
	wp_send_json( array_map( function ( $g ) {
		return array( 'id' => $g->ID, 'nome' => $g->post_title, 'cognome' => get_field( 'cognome', $g->ID ) );
	}, $giocatori ) );
}
add_action( 'wp_ajax_usrio_get_giocatori', 'usrio_ajax_get_giocatori' );

// Eventi di una squadra in un dato mese, con l'elenco degli id dei
// giocatori convocati per ogni partita, e se la persona collegata può
// modificare/eliminare ciascun evento (vero solo per i propri, per
// l'Allenatore; sempre falso per Giocatore e Socio, che guardano soltanto).
function usrio_ajax_get_eventi() {
	usrio_calendario_verifica_nonce();
	$squadra_id = isset( $_REQUEST['squadra_id'] ) ? absint( $_REQUEST['squadra_id'] ) : 0;
	$mese       = isset( $_REQUEST['mese'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['mese'] ) ) : '';

	if ( ! $squadra_id || ! preg_match( '/^\d{4}-\d{2}$/', $mese ) ) {
		wp_send_json_error( array( 'errore' => 'Parametri mancanti o non validi.' ), 400 );
	}

	list( $anno, $mese_num ) = array_map( 'intval', explode( '-', $mese ) );
	$primo  = sprintf( '%04d%02d01', $anno, $mese_num );
	$ultimo = sprintf( '%04d%02d%02d', $anno, $mese_num, (int) date( 't', mktime( 0, 0, 0, $mese_num, 1, $anno ) ) );

	$query = new WP_Query( array(
		'post_type'      => 'evento',
		'posts_per_page' => -1,
		'meta_query'     => array(
			'relation'    => 'AND',
			array( 'key' => 'squadra_evento', 'value' => $squadra_id, 'compare' => '=', 'type' => 'NUMERIC' ),
			'data_clause' => array( 'key' => 'data_evento', 'value' => array( $primo, $ultimo ), 'compare' => 'BETWEEN', 'type' => 'NUMERIC' ),
		),
		'orderby'        => array( 'data_clause' => 'ASC' ),
	) );

	$risultato = array();
	foreach ( $query->posts as $p ) {
		$convocati = array();
		if ( 'partita' === get_field( 'tipo_evento', $p->ID ) ) {
			$selezionati = get_field( 'convocati_evento', $p->ID );
			if ( $selezionati ) {
				foreach ( $selezionati as $g ) {
					$convocati[] = is_object( $g ) ? $g->ID : (int) $g;
				}
			}
		}
		$data_raw    = (string) get_field( 'data_evento', $p->ID );
		$risultato[] = array(
			'id'             => $p->ID,
			'tipo'           => get_field( 'tipo_evento', $p->ID ),
			'data'           => substr( $data_raw, 0, 4 ) . '-' . substr( $data_raw, 4, 2 ) . '-' . substr( $data_raw, 6, 2 ),
			'ora'            => get_field( 'ora_evento', $p->ID ),
			'luogo'          => get_field( 'luogo_evento', $p->ID ),
			'avversario'     => get_field( 'avversario_evento', $p->ID ),
			'casa_trasferta' => get_field( 'casa_trasferta_evento', $p->ID ),
			'note'           => get_field( 'note_evento', $p->ID ),
			'convocati'      => $convocati,
			'puo_modificare' => current_user_can( 'edit_post', $p->ID ),
		);
	}

	wp_send_json( $risultato );
}
add_action( 'wp_ajax_usrio_get_eventi', 'usrio_ajax_get_eventi' );

// Crea o modifica un evento (partita o allenamento). Per l'Allenatore la
// squadra è sempre forzata alla propria (usrio_evento_squadra_consentita),
// qualunque cosa arrivi dal modulo.
function usrio_ajax_salva_evento() {
	usrio_calendario_verifica_nonce();

	$evento_id      = isset( $_POST['evento_id'] ) ? absint( $_POST['evento_id'] ) : 0;
	$tipo           = ( isset( $_POST['tipo'] ) && 'allenamento' === $_POST['tipo'] ) ? 'allenamento' : 'partita';
	$data           = isset( $_POST['data'] ) ? sanitize_text_field( wp_unslash( $_POST['data'] ) ) : '';
	$ora            = isset( $_POST['ora'] ) ? sanitize_text_field( wp_unslash( $_POST['ora'] ) ) : '';
	$luogo          = isset( $_POST['luogo'] ) ? sanitize_text_field( wp_unslash( $_POST['luogo'] ) ) : '';
	$avversario     = isset( $_POST['avversario'] ) ? sanitize_text_field( wp_unslash( $_POST['avversario'] ) ) : '';
	$casa_trasferta = ( isset( $_POST['casa_trasferta'] ) && 'trasferta' === $_POST['casa_trasferta'] ) ? 'trasferta' : 'casa';
	$note           = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '';
	$squadra_id     = isset( $_POST['squadra_id'] ) ? absint( $_POST['squadra_id'] ) : 0;

	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $data ) ) {
		wp_send_json_error( array( 'errore' => 'Data mancante o non valida.' ), 400 );
	}
	if ( 'partita' === $tipo && ! $avversario ) {
		wp_send_json_error( array( 'errore' => "L'avversario è obbligatorio per una partita." ), 400 );
	}

	$squadra_id = usrio_evento_squadra_consentita( $squadra_id );
	if ( ! $squadra_id ) {
		wp_send_json_error( array( 'errore' => 'Squadra non valida o non assegnata.' ), 400 );
	}

	if ( $evento_id ) {
		if ( ! current_user_can( 'edit_post', $evento_id ) ) {
			wp_send_json_error( array( 'errore' => 'Non hai i permessi per modificare questo evento.' ), 403 );
		}
	} else {
		if ( ! current_user_can( 'edit_eventi' ) ) {
			wp_send_json_error( array( 'errore' => 'Non hai i permessi per creare un evento.' ), 403 );
		}
		$evento_id = wp_insert_post( array( 'post_type' => 'evento', 'post_status' => 'publish', 'post_title' => 'Evento' ), true );
		if ( is_wp_error( $evento_id ) ) {
			wp_send_json_error( array( 'errore' => $evento_id->get_error_message() ), 500 );
		}
	}

	$data_ymd = str_replace( '-', '', $data );

	update_field( 'tipo_evento', $tipo, $evento_id );
	update_field( 'squadra_evento', $squadra_id, $evento_id );
	update_field( 'data_evento', $data_ymd, $evento_id );
	update_field( 'ora_evento', $ora, $evento_id );
	update_field( 'luogo_evento', $luogo, $evento_id );
	update_field( 'avversario_evento', 'partita' === $tipo ? $avversario : '', $evento_id );
	update_field( 'casa_trasferta_evento', 'partita' === $tipo ? $casa_trasferta : '', $evento_id );
	update_field( 'note_evento', 'allenamento' === $tipo ? $note : '', $evento_id );

	wp_update_post( array( 'ID' => $evento_id, 'post_title' => usrio_generate_evento_title( $evento_id ) ) );

	wp_send_json_success( array( 'id' => $evento_id ) );
}
add_action( 'wp_ajax_usrio_salva_evento', 'usrio_ajax_salva_evento' );

// Elimina un evento (e le sue convocazioni, salvate nello stesso campo).
function usrio_ajax_elimina_evento() {
	usrio_calendario_verifica_nonce();
	$evento_id = isset( $_POST['evento_id'] ) ? absint( $_POST['evento_id'] ) : 0;
	if ( ! $evento_id || ! current_user_can( 'delete_post', $evento_id ) ) {
		wp_send_json_error( array( 'errore' => 'Non hai i permessi per eliminare questo evento.' ), 403 );
	}
	wp_delete_post( $evento_id, true );
	wp_send_json_success();
}
add_action( 'wp_ajax_usrio_elimina_evento', 'usrio_ajax_elimina_evento' );

// Sostituisce l'elenco dei convocati di una partita con quello ricevuto
// (le caselle spuntate nel modulo sul sito).
function usrio_ajax_salva_convocazioni() {
	usrio_calendario_verifica_nonce();
	$evento_id = isset( $_POST['evento_id'] ) ? absint( $_POST['evento_id'] ) : 0;
	if ( ! $evento_id || ! current_user_can( 'edit_post', $evento_id ) ) {
		wp_send_json_error( array( 'errore' => 'Non hai i permessi per modificare le convocazioni.' ), 403 );
	}
	$id_giocatori = array();
	if ( isset( $_POST['id_giocatori'] ) && is_array( $_POST['id_giocatori'] ) ) {
		$id_giocatori = array_map( 'absint', wp_unslash( $_POST['id_giocatori'] ) );
	}
	update_field( 'convocati_evento', $id_giocatori, $evento_id );
	wp_send_json_success();
}
add_action( 'wp_ajax_usrio_salva_convocazioni', 'usrio_ajax_salva_convocazioni' );

// ---------------------------------------------------------------------
// Pannello del Socio in "La Mia Area": gestisce la rosa (Giocatori) e gli
// accessi al sito (utenti con profilo Giocatore, Allenatore, Iscritto)
// direttamente da qui, senza mai passare da wp-admin.
// ---------------------------------------------------------------------
function usrio_verifica_permesso_socio() {
	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'errore' => "Devi effettuare l'accesso." ), 401 );
	}
	check_ajax_referer( 'usrio_area_riservata', 'nonce' );
	$user = wp_get_current_user();
	if ( ! in_array( 'socio', (array) $user->roles, true ) && ! in_array( 'administrator', (array) $user->roles, true ) ) {
		wp_send_json_error( array( 'errore' => 'Non hai i permessi per questa azione.' ), 403 );
	}
}

// Elenco delle squadre (per i menu a tendina del pannello).
function usrio_ajax_area_get_squadre() {
	usrio_verifica_permesso_socio();
	$squadre = get_posts( array( 'post_type' => 'squadra', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
	wp_send_json( array_map( function ( $s ) {
		return array( 'id' => $s->ID, 'nome' => $s->post_title );
	}, $squadre ) );
}
add_action( 'wp_ajax_usrio_area_get_squadre', 'usrio_ajax_area_get_squadre' );

// Aggiunge una squadra (categoria della società, es. "Juniores").
function usrio_ajax_area_salva_squadra() {
	usrio_verifica_permesso_socio();
	$nome = sanitize_text_field( wp_unslash( $_POST['nome'] ?? '' ) );
	if ( ! $nome ) {
		wp_send_json_error( array( 'errore' => 'Il nome della squadra è obbligatorio.' ), 400 );
	}
	$squadra_id = wp_insert_post( array( 'post_type' => 'squadra', 'post_status' => 'publish', 'post_title' => $nome ), true );
	if ( is_wp_error( $squadra_id ) ) {
		wp_send_json_error( array( 'errore' => $squadra_id->get_error_message() ), 500 );
	}
	wp_send_json_success( array( 'id' => $squadra_id ) );
}
add_action( 'wp_ajax_usrio_area_salva_squadra', 'usrio_ajax_area_salva_squadra' );

// Rimuove una squadra (non tocca i giocatori/eventi già collegati: restano
// nel database, semplicemente senza più una squadra valida, come già
// succede rimuovendo un responsabile o un giocatore).
function usrio_ajax_area_elimina_squadra() {
	usrio_verifica_permesso_socio();
	$id = absint( $_POST['squadra_id'] ?? 0 );
	if ( ! $id || 'squadra' !== get_post_type( $id ) ) {
		wp_send_json_error( array( 'errore' => 'Squadra non valida.' ), 400 );
	}
	wp_delete_post( $id, true );
	wp_send_json_success();
}
add_action( 'wp_ajax_usrio_area_elimina_squadra', 'usrio_ajax_area_elimina_squadra' );

// Rosa di una squadra (con il ruolo in campo), per la tabella del pannello
// e per scegliere a chi collegare un nuovo accesso Giocatore.
function usrio_ajax_area_get_giocatori() {
	usrio_verifica_permesso_socio();
	$squadra_id = isset( $_REQUEST['squadra_id'] ) ? absint( $_REQUEST['squadra_id'] ) : 0;
	$args = array( 'post_type' => 'giocatore', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' );
	if ( $squadra_id ) {
		$args['meta_query'] = array( array( 'key' => 'squadra', 'value' => $squadra_id, 'compare' => '=', 'type' => 'NUMERIC' ) );
	}
	$giocatori = get_posts( $args );
	wp_send_json( array_map( function ( $g ) {
		$squadra = get_field( 'squadra', $g->ID );
		return array(
			'id'           => $g->ID,
			'nome'         => $g->post_title,
			'cognome'      => get_field( 'cognome', $g->ID ),
			'ruolo'        => get_field( 'ruolo', $g->ID ),
			'squadra_nome' => $squadra ? $squadra->post_title : '',
		);
	}, $giocatori ) );
}
add_action( 'wp_ajax_usrio_area_get_giocatori', 'usrio_ajax_area_get_giocatori' );

// Aggiunge un giocatore alla rosa (la riga: nome, cognome, ruolo,
// squadra). Per dargli anche un accesso al sito serve poi creare un
// utente Giocatore e collegarlo dalla sezione "Accessi" dello stesso
// pannello.
function usrio_ajax_area_salva_giocatore() {
	usrio_verifica_permesso_socio();
	$nome       = sanitize_text_field( wp_unslash( $_POST['nome'] ?? '' ) );
	$cognome    = sanitize_text_field( wp_unslash( $_POST['cognome'] ?? '' ) );
	$ruolo      = sanitize_text_field( wp_unslash( $_POST['ruolo'] ?? '' ) );
	$squadra_id = absint( $_POST['squadra_id'] ?? 0 );

	if ( ! $nome || ! $cognome || ! $squadra_id ) {
		wp_send_json_error( array( 'errore' => 'Nome, cognome e squadra sono obbligatori.' ), 400 );
	}

	$giocatore_id = wp_insert_post( array( 'post_type' => 'giocatore', 'post_status' => 'publish', 'post_title' => $nome ), true );
	if ( is_wp_error( $giocatore_id ) ) {
		wp_send_json_error( array( 'errore' => $giocatore_id->get_error_message() ), 500 );
	}
	update_field( 'cognome', $cognome, $giocatore_id );
	update_field( 'ruolo', $ruolo, $giocatore_id );
	update_field( 'squadra', $squadra_id, $giocatore_id );

	wp_send_json_success( array( 'id' => $giocatore_id ) );
}
add_action( 'wp_ajax_usrio_area_salva_giocatore', 'usrio_ajax_area_salva_giocatore' );

// Rimuove un giocatore dalla rosa.
function usrio_ajax_area_elimina_giocatore() {
	usrio_verifica_permesso_socio();
	$id = absint( $_POST['giocatore_id'] ?? 0 );
	if ( ! $id || 'giocatore' !== get_post_type( $id ) ) {
		wp_send_json_error( array( 'errore' => 'Giocatore non valido.' ), 400 );
	}
	wp_delete_post( $id, true );
	wp_send_json_success();
}
add_action( 'wp_ajax_usrio_area_elimina_giocatore', 'usrio_ajax_area_elimina_giocatore' );

// Elenco degli accessi (utenti) con un profilo gestibile dal Socio
// (Giocatore, Allenatore, Iscritto), con la squadra o la riga di rosa a
// cui risultano collegati.
function usrio_ajax_area_get_utenti() {
	usrio_verifica_permesso_socio();
	$utenti = get_users( array( 'role__in' => array( 'giocatore', 'allenatore', 'iscritto' ) ) );
	wp_send_json( array_map( function ( $u ) {
		$ruolo = ! empty( $u->roles ) ? $u->roles[0] : '';
		$collegamento = null;
		if ( 'allenatore' === $ruolo ) {
			$squadra = get_field( 'squadra_assegnata', 'user_' . $u->ID );
			$collegamento = $squadra ? $squadra->post_title : null;
		} elseif ( 'giocatore' === $ruolo ) {
			$giocatore = get_field( 'giocatore_collegato', 'user_' . $u->ID );
			$collegamento = $giocatore ? $giocatore->post_title : null;
		}
		return array(
			'id'           => $u->ID,
			'nome'         => $u->display_name,
			'email'        => $u->user_email,
			'ruolo'        => $ruolo,
			'collegamento' => $collegamento,
		);
	}, $utenti ) );
}
add_action( 'wp_ajax_usrio_area_get_utenti', 'usrio_ajax_area_get_utenti' );

// Crea un nuovo accesso al sito (utente WordPress) con il profilo scelto
// dal Socio — Giocatore, Allenatore o Iscritto — collegandolo subito, se
// serve, alla squadra (Allenatore) o alla riga di rosa (Giocatore): come
// farebbe Utenti → Aggiungi nuovo in wp-admin, ma dal sito. La password
// viene generata e inviata via email, come fa WordPress di norma.
function usrio_ajax_area_crea_utente() {
	usrio_verifica_permesso_socio();

	$nome         = sanitize_text_field( wp_unslash( $_POST['nome'] ?? '' ) );
	$cognome      = sanitize_text_field( wp_unslash( $_POST['cognome'] ?? '' ) );
	$email        = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$ruolo        = sanitize_text_field( wp_unslash( $_POST['ruolo'] ?? '' ) );
	$squadra_id   = absint( $_POST['squadra_id'] ?? 0 );
	$giocatore_id = absint( $_POST['giocatore_id'] ?? 0 );

	$ruoli_ammessi = array( 'giocatore', 'allenatore', 'iscritto' );
	if ( ! $nome || ! $cognome || ! $email || ! in_array( $ruolo, $ruoli_ammessi, true ) ) {
		wp_send_json_error( array( 'errore' => 'Nome, cognome, email e profilo sono obbligatori.' ), 400 );
	}
	if ( ! is_email( $email ) ) {
		wp_send_json_error( array( 'errore' => "L'email non è valida." ), 400 );
	}
	if ( email_exists( $email ) || username_exists( $email ) ) {
		wp_send_json_error( array( 'errore' => 'Esiste già un accesso con questa email.' ), 400 );
	}
	if ( 'allenatore' === $ruolo && ! $squadra_id ) {
		wp_send_json_error( array( 'errore' => "Scegli la squadra da assegnare all'Allenatore." ), 400 );
	}

	$user_id = wp_insert_user( array(
		'user_login'   => $email,
		'user_email'   => $email,
		'user_pass'    => wp_generate_password( 16 ),
		'first_name'   => $nome,
		'last_name'    => $cognome,
		'display_name' => trim( $nome . ' ' . $cognome ),
		'role'         => $ruolo,
	) );
	if ( is_wp_error( $user_id ) ) {
		wp_send_json_error( array( 'errore' => $user_id->get_error_message() ), 500 );
	}

	if ( 'allenatore' === $ruolo && $squadra_id ) {
		update_field( 'squadra_assegnata', $squadra_id, 'user_' . $user_id );
	}
	if ( 'giocatore' === $ruolo && $giocatore_id ) {
		update_field( 'giocatore_collegato', $giocatore_id, 'user_' . $user_id );
	}

	// Manda subito l'email con il link per impostare la password, come fa
	// wp-admin creando un utente da Utenti → Aggiungi nuovo.
	wp_new_user_notification( $user_id, null, 'both' );

	wp_send_json_success( array( 'id' => $user_id ) );
}
add_action( 'wp_ajax_usrio_area_crea_utente', 'usrio_ajax_area_crea_utente' );

// Rimuove un accesso (utente) creato dal Socio.
function usrio_ajax_area_elimina_utente() {
	usrio_verifica_permesso_socio();
	$id     = absint( $_POST['utente_id'] ?? 0 );
	$utente = get_userdata( $id );
	if ( ! $utente || ! array_intersect( array( 'giocatore', 'allenatore', 'iscritto' ), (array) $utente->roles ) ) {
		wp_send_json_error( array( 'errore' => 'Accesso non valido.' ), 400 );
	}
	require_once ABSPATH . 'wp-admin/includes/user.php';
	wp_delete_user( $id );
	wp_send_json_success();
}
add_action( 'wp_ajax_usrio_area_elimina_utente', 'usrio_ajax_area_elimina_utente' );
