<?php
/**
 * Home page. Le due colonne laterali dell'hero (la "cascata" di riquadri
 * segnaposto) sono generate in JavaScript (js/site.js), esattamente come
 * nella versione precedente del sito: è un effetto solo decorativo.
 */
get_header();

$usrio_user      = wp_get_current_user();
$usrio_logged_in = is_user_logged_in();
$usrio_role      = $usrio_logged_in && ! empty( $usrio_user->roles ) ? $usrio_user->roles[0] : '';
?>

<div class="hero">
	<div class="hero-cascade-side" id="heroCascadeLeft" aria-hidden="true"></div>
	<div class="hero-inner">
		<p class="eyebrow">Affiliata Calcio Padova</p>
		<h1>U.S. RIO A.S.D.</h1>
		<p>Il sito ufficiale della società: storia, squadre, notizie e tutto ciò che riguarda U.S. Rio.</p>
		<div class="hero-crest">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/img/logo.png' ); ?>" alt="Stemma U.S. Rio">
		</div>
	</div>
	<div class="hero-cascade-side" id="heroCascadeRight" aria-hidden="true"></div>
</div>

<div class="view-inner">
	<div class="showcase-grid">
		<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/societa/' ) ); ?>">
			<div class="thumb"><?php usrio_icon_photo(); ?></div>
			<div class="body">
				<span class="name">Società</span>
				<span class="desc">Chi siamo e l'affiliazione con il Calcio Padova.</span>
			</div>
		</div>
		<div class="showcase-card" data-href="<?php echo esc_url( get_post_type_archive_link( 'squadra' ) ); ?>">
			<div class="thumb"><?php usrio_icon_photo(); ?></div>
			<div class="body">
				<span class="name">Squadre</span>
				<span class="desc">Le categorie della società, dal settore giovanile alla prima squadra.</span>
			</div>
		</div>
		<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/bacheca/' ) ); ?>">
			<div class="thumb"><?php usrio_icon_photo(); ?></div>
			<div class="body">
				<span class="name">Bacheca</span>
				<span class="desc">Notizie, risultati e comunicati.</span>
			</div>
		</div>
		<?php if ( in_array( $usrio_role, array( 'giocatore', 'allenatore' ), true ) ) : ?>
			<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/area-riservata/' ) ); ?>">
				<div class="thumb"><?php usrio_icon_photo(); ?></div>
				<div class="body">
					<span class="name">La Mia Area</span>
					<span class="desc"><?php echo 'allenatore' === $usrio_role ? 'Bacheca delle squadre che alleni.' : 'Bacheca della tua squadra e il tuo certificato medico.'; ?></span>
					<span class="tag">Personale</span>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>

<?php get_footer(); ?>
