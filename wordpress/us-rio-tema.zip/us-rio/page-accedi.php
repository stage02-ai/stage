<?php
/**
 * Pagina di accesso (slug: accedi). A differenza della versione
 * precedente, qui il controllo di email e password è vero: usa il
 * sistema di login di WordPress (wp_signon), non più una semplice
 * anteprima grafica.
 *
 * La creazione di nuovi utenti (Giocatore, Allenatore, Iscritto) non è
 * più "auto-registrazione" libera come nella versione precedente: la
 * crea il Socio dal pannello di amministrazione (Utenti → Aggiungi
 * nuovo), scegliendo lui il profilo giusto — è il modo corretto per un
 * sito reale, ed evita che chiunque si assegni da solo un ruolo.
 */

$usrio_login_error = '';

if ( is_user_logged_in() ) {
	wp_safe_redirect( home_url( '/' ) );
	exit;
}

if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['usrio_login_nonce'] ) ) {
	if ( ! wp_verify_nonce( $_POST['usrio_login_nonce'], 'usrio_login' ) ) {
		$usrio_login_error = 'Richiesta non valida, riprova.';
	} else {
		$creds = array(
			'user_login'    => sanitize_text_field( wp_unslash( $_POST['usrio_email'] ?? '' ) ),
			'user_password' => $_POST['usrio_password'] ?? '',
			'remember'      => true,
		);

		if ( empty( $creds['user_login'] ) || empty( $creds['user_password'] ) ) {
			$usrio_login_error = 'Inserisci email/nome utente e password.';
		} else {
			$user = wp_signon( $creds, false );
			if ( is_wp_error( $user ) ) {
				$usrio_login_error = 'Email o password non corrette.';
			} else {
				wp_set_current_user( $user->ID );
				// Sempre alla home del sito, mai a wp-admin: per nessun
				// profilo, Socio incluso (tutto avviene sul sito).
				wp_safe_redirect( home_url( '/' ) );
				exit;
			}
		}
	}
}

get_header();
?>
<div class="view-inner login-page">
	<div class="view-header">
		<p class="eyebrow">Area riservata</p>
		<h1>Accedi</h1>
		<p class="view-sub">Inserisci le credenziali che ti ha fornito il Socio.</p>
	</div>

	<div class="login-card">
		<form class="login-form" method="post" action="<?php echo esc_url( home_url( '/accedi/' ) ); ?>" novalidate>
			<?php wp_nonce_field( 'usrio_login', 'usrio_login_nonce' ); ?>
			<label class="form-group">
				<span>Email o nome utente</span>
				<input type="text" name="usrio_email" placeholder="nome@esempio.it" autocomplete="username">
			</label>
			<label class="form-group">
				<span>Password</span>
				<input type="password" name="usrio_password" placeholder="********" autocomplete="current-password">
			</label>
			<p class="form-error"><?php echo esc_html( $usrio_login_error ); ?></p>
			<button type="submit" class="btn-primary">Accedi</button>
		</form>
	</div>

	<div class="placeholder-card">
		<strong>Non hai ancora le credenziali?</strong> Le crea il Socio dal pannello di amministrazione del sito, scegliendo il tuo profilo (Giocatore, Allenatore, Iscritto). Contatta la società per farti registrare.
	</div>
</div>
<?php get_footer(); ?>
