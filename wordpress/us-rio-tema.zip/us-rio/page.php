<?php
/** Template generico per una pagina qualsiasi creata in WordPress senza
 * un template dedicato: mostra semplicemente il titolo e il contenuto
 * scritti nel pannello di amministrazione. */
get_header();
while ( have_posts() ) : the_post();
	?>
	<div class="view-inner">
		<div class="view-header">
			<h1><?php the_title(); ?></h1>
		</div>
		<div class="prose">
			<?php the_content(); ?>
		</div>
	</div>
	<?php
endwhile;
get_footer();
