<?php
/** Template: pagina "Storia" (slug: storia) */
get_header();
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Società &rsaquo; Storia</p>
		<h1>Storia</h1>
		<p class="view-sub">Le tappe principali della storia di U.S. Rio A.S.D.</p>
	</div>
	<div class="photo-slot photo-slot-chibi">
		<div class="hero-photo-row"><?php usrio_icon_photo(); ?></div>
		<span>Foto storiche in arrivo</span>
	</div>
	<div class="placeholder-card">
		<strong>🚧 Testo segnaposto.</strong> Qui andrà la storia reale della società: anno di fondazione, tappe principali, eventuali fusioni o cambi di denominazione, risultati storici e aneddoti. In attesa dei contenuti reali da parte della società.
	</div>
</div>
<?php get_footer(); ?>
