<?php
/** Certificato medico personale (slug: certificato-personale), solo Giocatore. */
get_header();

if ( ! is_user_logged_in() || ! in_array( 'giocatore', (array) wp_get_current_user()->roles, true ) ) {
	echo '<div class="view-inner"><div class="placeholder-card"><strong>🚧 Area riservata.</strong> Questa pagina è visibile solo al profilo Giocatore.</div></div>';
	get_footer();
	return;
}

$user = wp_get_current_user();
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">La Mia Area &rsaquo; Certificato Medico</p>
		<h1>Il tuo certificato medico</h1>
		<p class="view-sub">Qui vedi solo il tuo certificato, non quello degli altri giocatori.</p>
	</div>
	<table class="table-preview">
		<tr><th>Giocatore</th><th>Scadenza</th><th>Stato</th></tr>
		<tr><td><?php echo esc_html( $user->display_name ); ?></td><td>14/12/2026</td><td><span class="status-dot ok"></span>Valido</td></tr>
	</table>
	<div class="placeholder-card">
		<strong>🚧 Solo anteprima grafica.</strong> Data e stato reali verranno letti dal database in un prossimo passo (modulo Certificati Medici, ancora da avviare).
	</div>
</div>
<?php get_footer(); ?>
