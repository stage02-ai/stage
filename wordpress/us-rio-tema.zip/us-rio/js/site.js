// Piccoli comportamenti del sito: apertura/chiusura menu mobile, click
// sulle card "vetrina" (che sono div, non link, per motivi grafici) e la
// cascata decorativa dell'hero in home. Nessuna logica di accesso qui:
// se ne occupa WordPress stesso (login reale, non più finto).

document.addEventListener('DOMContentLoaded', () => {
  const mobileMenu = document.getElementById('mobileMenu');
  const menuToggle = document.getElementById('menuToggle');
  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener('click', () => mobileMenu.classList.toggle('open'));
  }

  document.querySelectorAll('[data-href]').forEach((card) => {
    card.style.cursor = 'pointer';
    card.addEventListener('click', () => {
      if (card.dataset.href) window.location.href = card.dataset.href;
    });
  });

  const left = document.getElementById('heroCascadeLeft');
  const right = document.getElementById('heroCascadeRight');
  if (left) left.innerHTML = heroCascadeSide(34);
  if (right) right.innerHTML = heroCascadeSide(40);

  // La Bacheca Squadra (calendario partite/allenamenti) ha una sua
  // logica a parte, caricata solo in quella pagina: vedi
  // js/bacheca-calendario.js.
});

const ICON_PHOTO_SVG = '<svg viewBox="0 0 100 100" class="icon-illustration"><rect x="8" y="20" width="84" height="64" rx="8"/><circle cx="34" cy="42" r="9"/><path d="M12 74 L38 48 L56 64 L72 44 L88 62"/></svg>';

function heroCascadePanelRows() {
  const rowCount = 9 + Math.floor(Math.random() * 3);
  let rows = '';
  for (let i = 0; i < rowCount; i += 1) {
    const height = Math.round(74 + Math.random() * 46);
    const panelBasis = () => Math.round(height * (0.75 + Math.random() * 0.5));
    const roll = Math.random();
    const panelCount = roll < 0.35 ? 1 : (roll < 0.75 ? 2 : 3);
    const panels = Array.from({ length: panelCount })
      .map(() => `<div class="cascade-panel" style="flex-basis:${panelBasis()}px;">${ICON_PHOTO_SVG}</div>`)
      .join('');
    rows += `<div class="cascade-row" style="height:${height}px;">${panels}</div>`;
  }
  return rows;
}

function heroCascadeSide(duration) {
  const rowsHtml = heroCascadePanelRows();
  return `<div class="cascade-strip" style="--duration:${duration}s;">${rowsHtml}${rowsHtml}</div>`;
}
