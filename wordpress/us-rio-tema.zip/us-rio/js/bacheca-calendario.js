// Bacheca Squadra: calendario mensile di partite e allenamenti, gestito
// interamente qui sul sito (niente wp-admin). Stessa logica e stessa
// grafica della versione Node.js del progetto, solo collegata agli
// endpoint AJAX di WordPress (registrati in functions.php) invece delle
// rotte Express. Caricato solo nella pagina Bacheca Squadra.

document.addEventListener('DOMContentLoaded', () => {
  const wrap = document.getElementById('calendarWrap');
  if (!wrap || typeof UsrioCalendarioAjax === 'undefined') return;

  const MESI_IT = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  const GIORNI_IT = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];

  const init = window.UsrioCalendarioInit || {};
  let calendarSquadraId = init.squadraId || null;
  let calendarSquadraNome = init.squadraNome || '';
  const calendarCanEdit = !!init.puoModificare;
  const calendarSquadraFissa = !!init.squadraFissa;
  let calendarAnno = null;
  let calendarMese = null; // 1-12
  let calendarEventi = [];
  let calendarGiocatori = [];
  let calendarGiornoSelezionato = null; // 'AAAA-MM-GG'
  let calendarFormAperto = null; // null | 'partita' | 'allenamento'
  let calendarEventoInModifica = null;

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function formatDataISO(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function showCalStatus(msg, isError) {
    const el = document.getElementById('calStatus');
    if (!el) return;
    el.textContent = msg;
    el.classList.toggle('is-error', !!isError);
    if (!isError) {
      setTimeout(() => { if (el.textContent === msg) el.textContent = ''; }, 3000);
    }
  }

  function armRemoveButton(btn, onConfirm) {
    if (btn.dataset.armed === 'true') {
      clearTimeout(Number(btn.dataset.armTimer));
      onConfirm();
      return;
    }
    btn.dataset.armed = 'true';
    btn.dataset.originalLabel = btn.textContent;
    btn.textContent = 'Confermi?';
    btn.classList.add('is-armed');
    const timer = setTimeout(() => {
      btn.dataset.armed = 'false';
      btn.textContent = btn.dataset.originalLabel;
      btn.classList.remove('is-armed');
    }, 4000);
    btn.dataset.armTimer = String(timer);
  }

  async function ajaxGet(action, params) {
    const query = new URLSearchParams({ action, nonce: UsrioCalendarioAjax.nonce, ...params });
    const res = await fetch(`${UsrioCalendarioAjax.url}?${query.toString()}`);
    return res.ok ? res.json() : null;
  }

  async function ajaxPost(action, params) {
    const body = new URLSearchParams({ action, nonce: UsrioCalendarioAjax.nonce });
    Object.entries(params || {}).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        value.forEach((v) => body.append(`${key}[]`, v));
      } else if (value !== undefined && value !== null) {
        body.append(key, value);
      }
    });
    const res = await fetch(UsrioCalendarioAjax.url, { method: 'POST', body });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, data };
  }

  async function populateCalendarSquadraSelect() {
    const sel = document.getElementById('calendarSquadraSelect');
    if (!sel) return;
    const squadre = await ajaxGet('usrio_get_squadre') || [];
    if (!squadre.length) {
      sel.innerHTML = '<option value="">Nessuna squadra nel database</option>';
      calendarSquadraId = null;
      calendarSquadraNome = '';
      return;
    }
    if (!calendarSquadraId || !squadre.some((s) => String(s.id) === String(calendarSquadraId))) {
      calendarSquadraId = String(squadre[0].id);
    }
    const attuale = squadre.find((s) => String(s.id) === String(calendarSquadraId));
    calendarSquadraNome = attuale ? attuale.nome : '';
    sel.innerHTML = squadre.map((s) => `
      <option value="${s.id}" ${String(s.id) === String(calendarSquadraId) ? 'selected' : ''}>${escapeHtml(s.nome)}</option>
    `).join('');
  }

  async function loadCalendarMese() {
    if (!calendarSquadraId) {
      wrap.innerHTML = '<p class="loading-note">Scegli una squadra per vedere la sua bacheca.</p>';
      return;
    }
    wrap.innerHTML = '<p class="loading-note">Caricamento calendario…</p>';
    const meseParam = `${calendarAnno}-${String(calendarMese).padStart(2, '0')}`;
    const [eventi, giocatori] = await Promise.all([
      ajaxGet('usrio_get_eventi', { squadra_id: calendarSquadraId, mese: meseParam }),
      ajaxGet('usrio_get_giocatori', { squadra_id: calendarSquadraId }),
    ]);
    calendarEventi = Array.isArray(eventi) ? eventi : [];
    calendarGiocatori = Array.isArray(giocatori) ? giocatori : [];
    renderCalendarShell();
  }

  function renderCalendarShell() {
    if (!calendarSquadraId) {
      wrap.innerHTML = '<p class="loading-note">Scegli una squadra per vedere la sua bacheca.</p>';
      return;
    }
    wrap.innerHTML = `
      <div class="cal-header">
        <button type="button" class="cal-nav" data-cal-nav="-1" aria-label="Mese precedente">&larr;</button>
        <h2 class="cal-title">${MESI_IT[calendarMese - 1]} ${calendarAnno}</h2>
        <button type="button" class="cal-nav" data-cal-nav="1" aria-label="Mese successivo">&rarr;</button>
      </div>
      <div class="cal-legend">
        <span class="cal-legend-item"><span class="cal-dot partita"></span> Partita</span>
        <span class="cal-legend-item"><span class="cal-dot allenamento"></span> Allenamento</span>
      </div>
      <div class="cal-grid">
        ${GIORNI_IT.map((g) => `<div class="cal-weekday">${g}</div>`).join('')}
        ${renderCalendarCelle()}
      </div>
      <div class="cal-detail" id="calDetail">${renderCalendarDettaglio()}</div>
    `;
  }

  function renderCalendarCelle() {
    const primoGiorno = new Date(calendarAnno, calendarMese - 1, 1);
    const numGiorni = new Date(calendarAnno, calendarMese, 0).getDate();
    const offset = (primoGiorno.getDay() + 6) % 7; // Lunedì = 0

    const oggiISO = formatDataISO(new Date());
    let celle = '';

    for (let i = 0; i < offset; i += 1) {
      celle += '<div class="cal-day is-other-month"></div>';
    }

    for (let giorno = 1; giorno <= numGiorni; giorno += 1) {
      const dataISO = `${calendarAnno}-${String(calendarMese).padStart(2, '0')}-${String(giorno).padStart(2, '0')}`;
      const eventiGiorno = calendarEventi.filter((ev) => ev.data === dataISO);
      const chips = eventiGiorno.slice(0, 3).map((ev) => `
        <span class="cal-chip ${ev.tipo}">${ev.tipo === 'partita' ? `vs ${escapeHtml(ev.avversario || '?')}` : 'Allenamento'}</span>
      `).join('');
      const extra = eventiGiorno.length > 3 ? `<span class="cal-chip-extra">+${eventiGiorno.length - 3}</span>` : '';

      celle += `
        <div class="cal-day ${dataISO === oggiISO ? 'is-today' : ''} ${dataISO === calendarGiornoSelezionato ? 'is-selected' : ''}" data-cal-day="${dataISO}">
          <span class="cal-day-number">${giorno}</span>
          <div class="cal-chips">${chips}${extra}</div>
        </div>
      `;
    }

    const restanti = (7 - ((offset + numGiorni) % 7)) % 7;
    for (let i = 0; i < restanti; i += 1) {
      celle += '<div class="cal-day is-other-month"></div>';
    }

    return celle;
  }

  function renderCalendarDettaglio() {
    if (!calendarGiornoSelezionato) {
      return '<p class="loading-note">Clicca su un giorno del calendario per vederne i dettagli.</p>';
    }

    const dataObj = new Date(`${calendarGiornoSelezionato}T00:00:00`);
    const giorniSettimana = ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'];
    const dataLabel = `${giorniSettimana[dataObj.getDay()]} ${dataObj.getDate()} ${MESI_IT[dataObj.getMonth()]} ${dataObj.getFullYear()}`;
    const eventiGiorno = calendarEventi.filter((ev) => ev.data === calendarGiornoSelezionato);

    let html = `<h3 class="cal-detail-title">${escapeHtml(dataLabel)}</h3>`;

    if (calendarFormAperto && !calendarEventoInModifica) {
      html += renderCalendarForm();
    } else if (!eventiGiorno.length) {
      html += '<p class="loading-note">Nessun evento in questo giorno.</p>';
    } else {
      html += eventiGiorno.map((ev) => renderCalendarEvento(ev)).join('');
    }

    if (calendarCanEdit && !calendarFormAperto) {
      html += `
        <div class="cal-add-buttons">
          <button type="button" class="btn-primary" data-cal-nuovo="partita">+ Partita</button>
          <button type="button" class="btn-primary" data-cal-nuovo="allenamento">+ Allenamento</button>
        </div>
      `;
    }

    return html;
  }

  function renderCalendarEvento(ev) {
    if (calendarEventoInModifica === ev.id && calendarFormAperto) {
      return renderCalendarForm();
    }

    const dettagli = ev.tipo === 'partita'
      ? `${ev.casa_trasferta === 'trasferta' ? 'Trasferta' : 'Casa'} contro ${escapeHtml(ev.avversario || 'avversario da definire')}`
      : escapeHtml(ev.note || 'Allenamento');

    return `
      <div class="cal-event-item cal-event-${ev.tipo}">
        <div class="cal-event-head">
          <span class="cal-event-tipo">${ev.tipo === 'partita' ? '⚽ Partita' : '🏃 Allenamento'}</span>
          ${ev.ora ? `<span class="cal-event-ora">${escapeHtml(String(ev.ora).slice(0, 5))}</span>` : ''}
        </div>
        <p class="cal-event-dettagli">${dettagli}${ev.luogo ? ` &middot; ${escapeHtml(ev.luogo)}` : ''}</p>
        ${calendarCanEdit ? `
          <div class="cal-event-actions">
            <button type="button" class="btn-secondary-small" data-cal-modifica="${ev.id}">Modifica</button>
            <button type="button" class="btn-remove-row" data-cal-elimina="${ev.id}">Elimina</button>
          </div>
        ` : ''}
        ${ev.tipo === 'partita' ? renderConvocazioni(ev) : ''}
      </div>
    `;
  }

  function renderConvocazioni(ev) {
    const convocatiIds = (ev.convocati || []).map(String);

    if (!calendarCanEdit) {
      const nomi = calendarGiocatori
        .filter((g) => convocatiIds.includes(String(g.id)))
        .map((g) => `${g.nome} ${g.cognome}`);
      return `
        <div class="cal-convocazioni">
          <p class="cal-convocazioni-title">Convocati</p>
          ${nomi.length ? `<p>${nomi.map(escapeHtml).join(', ')}</p>` : '<p class="loading-note">Nessuna convocazione impostata.</p>'}
        </div>
      `;
    }

    if (!calendarGiocatori.length) {
      return `
        <div class="cal-convocazioni">
          <p class="cal-convocazioni-title">Convocati</p>
          <p class="loading-note">Nessun giocatore in rosa: aggiungilo dal pannello del Socio prima di convocarlo.</p>
        </div>
      `;
    }

    return `
      <div class="cal-convocazioni">
        <p class="cal-convocazioni-title">Convocati</p>
        <div class="cal-convocati-list" data-cal-convocazioni-evento="${ev.id}">
          ${calendarGiocatori.map((g) => `
            <label class="cal-convocato-row">
              <input type="checkbox" value="${g.id}" ${convocatiIds.includes(String(g.id)) ? 'checked' : ''}>
              <span>${escapeHtml(g.nome)} ${escapeHtml(g.cognome)}</span>
            </label>
          `).join('')}
        </div>
        <button type="button" class="btn-secondary-small" data-cal-salva-convocazioni="${ev.id}">Salva convocazioni</button>
      </div>
    `;
  }

  function renderCalendarForm() {
    const editing = calendarEventoInModifica ? calendarEventi.find((e) => e.id === calendarEventoInModifica) : null;
    const tipo = editing ? editing.tipo : calendarFormAperto;

    return `
      <form class="admin-form cal-form" id="calendarEventoForm" data-tipo="${tipo}" data-evento-id="${editing ? editing.id : ''}" novalidate>
        <p class="cal-form-title">${editing ? 'Modifica' : 'Nuovo'} ${tipo === 'partita' ? 'partita' : 'allenamento'}</p>
        <label class="form-group">
          <span>Orario</span>
          <input type="time" id="calEventoOra" value="${editing && editing.ora ? String(editing.ora).slice(0, 5) : ''}">
        </label>
        <label class="form-group">
          <span>Luogo</span>
          <input type="text" id="calEventoLuogo" placeholder="Es. Campo comunale" value="${editing ? escapeHtml(editing.luogo || '') : ''}">
        </label>
        ${tipo === 'partita' ? `
          <label class="form-group">
            <span>Avversario</span>
            <input type="text" id="calEventoAvversario" placeholder="Es. A.S.D. Juniores" value="${editing ? escapeHtml(editing.avversario || '') : ''}">
          </label>
          <label class="form-group">
            <span>Casa o trasferta</span>
            <select id="calEventoCasaTrasferta">
              <option value="casa" ${!editing || editing.casa_trasferta === 'casa' ? 'selected' : ''}>Casa</option>
              <option value="trasferta" ${editing && editing.casa_trasferta === 'trasferta' ? 'selected' : ''}>Trasferta</option>
            </select>
          </label>
          ${renderConvocazioniForm(editing)}
        ` : `
          <label class="form-group">
            <span>Note (facoltative)</span>
            <input type="text" id="calEventoNote" placeholder="Es. Portare parastinchi" value="${editing ? escapeHtml(editing.note || '') : ''}">
          </label>
        `}
        <p class="form-error" id="calEventoError"></p>
        <div class="cal-form-actions">
          <button type="submit" class="btn-primary">${editing ? 'Salva modifiche' : 'Aggiungi'}</button>
          <button type="button" class="btn-secondary-small" data-cal-annulla="1">Annulla</button>
        </div>
      </form>
    `;
  }

  // Caselle da spuntare per scegliere subito i convocati mentre si crea o
  // modifica una partita (giocatori veri della rosa, mai nomi a caso): così
  // non serve più salvare prima la partita e poi tornare a impostare le
  // convocazioni in un secondo momento.
  function renderConvocazioniForm(editing) {
    const convocatiIds = ((editing && editing.convocati) || []).map(String);

    if (!calendarGiocatori.length) {
      return `
        <div class="cal-convocazioni cal-form-convocazioni">
          <p class="cal-convocazioni-title">Convocati</p>
          <p class="loading-note">Nessun giocatore in rosa: aggiungilo dal pannello del Socio prima di convocarlo.</p>
        </div>
      `;
    }

    return `
      <div class="cal-convocazioni cal-form-convocazioni">
        <p class="cal-convocazioni-title">Convocati</p>
        <div class="cal-convocati-list" data-cal-form-convocati>
          ${calendarGiocatori.map((g) => `
            <label class="cal-convocato-row">
              <input type="checkbox" value="${g.id}" ${convocatiIds.includes(String(g.id)) ? 'checked' : ''}>
              <span>${escapeHtml(g.nome)} ${escapeHtml(g.cognome)}</span>
            </label>
          `).join('')}
        </div>
      </div>
    `;
  }

  // ---- Interazioni ----

  wrap.addEventListener('click', (e) => {
    const calNav = e.target.closest('[data-cal-nav]');
    if (calNav) {
      calendarMese += Number(calNav.dataset.calNav);
      if (calendarMese > 12) { calendarMese = 1; calendarAnno += 1; }
      if (calendarMese < 1) { calendarMese = 12; calendarAnno -= 1; }
      calendarGiornoSelezionato = null;
      calendarFormAperto = null;
      calendarEventoInModifica = null;
      loadCalendarMese();
      return;
    }

    const calDay = e.target.closest('[data-cal-day]');
    if (calDay) {
      calendarGiornoSelezionato = calDay.dataset.calDay;
      calendarFormAperto = null;
      calendarEventoInModifica = null;
      renderCalendarShell();
      return;
    }

    const calNuovo = e.target.closest('[data-cal-nuovo]');
    if (calNuovo) {
      calendarFormAperto = calNuovo.dataset.calNuovo;
      calendarEventoInModifica = null;
      document.getElementById('calDetail').innerHTML = renderCalendarDettaglio();
      return;
    }

    const calModifica = e.target.closest('[data-cal-modifica]');
    if (calModifica) {
      calendarEventoInModifica = Number(calModifica.dataset.calModifica);
      const ev = calendarEventi.find((x) => x.id === calendarEventoInModifica);
      calendarFormAperto = ev ? ev.tipo : null;
      document.getElementById('calDetail').innerHTML = renderCalendarDettaglio();
      return;
    }

    const calAnnulla = e.target.closest('[data-cal-annulla]');
    if (calAnnulla) {
      calendarFormAperto = null;
      calendarEventoInModifica = null;
      document.getElementById('calDetail').innerHTML = renderCalendarDettaglio();
      return;
    }

    const calElimina = e.target.closest('[data-cal-elimina]');
    if (calElimina) {
      armRemoveButton(calElimina, async () => {
        const { ok, data } = await ajaxPost('usrio_elimina_evento', { evento_id: calElimina.dataset.calElimina });
        if (!ok) {
          showCalStatus(`Errore: ${(data && data.data && data.data.errore) || 'richiesta non riuscita'}`, true);
          return;
        }
        await loadCalendarMese();
      });
      return;
    }

    const calSalvaConvocazioni = e.target.closest('[data-cal-salva-convocazioni]');
    if (calSalvaConvocazioni) {
      const eventoId = calSalvaConvocazioni.dataset.calSalvaConvocazioni;
      const container = calSalvaConvocazioni.closest('.cal-convocazioni').querySelector('[data-cal-convocazioni-evento]');
      const idGiocatori = Array.from(container.querySelectorAll('input[type="checkbox"]:checked')).map((cb) => cb.value);
      (async () => {
        const { ok, data } = await ajaxPost('usrio_salva_convocazioni', { evento_id: eventoId, id_giocatori: idGiocatori });
        if (!ok) {
          showCalStatus(`Errore: ${(data && data.data && data.data.errore) || 'richiesta non riuscita'}`, true);
          return;
        }
        showCalStatus('Convocazioni salvate.');
        await loadCalendarMese();
      })();
    }
  });

  document.addEventListener('change', (e) => {
    if (e.target.id === 'calendarSquadraSelect') {
      calendarSquadraId = e.target.value;
      const opt = e.target.selectedOptions[0];
      calendarSquadraNome = opt ? opt.textContent : '';
      calendarGiornoSelezionato = null;
      calendarFormAperto = null;
      calendarEventoInModifica = null;
      loadCalendarMese();
    }
  });

  document.addEventListener('submit', async (e) => {
    if (e.target.id !== 'calendarEventoForm') return;
    e.preventDefault();

    const form = e.target;
    const tipo = form.dataset.tipo;
    const eventoId = form.dataset.eventoId;
    const errorEl = document.getElementById('calEventoError');
    errorEl.textContent = '';

    const payload = {
      squadra_id: calendarSquadraId,
      tipo,
      data: calendarGiornoSelezionato,
      ora: document.getElementById('calEventoOra').value || '',
      luogo: (document.getElementById('calEventoLuogo').value || '').trim(),
    };

    if (tipo === 'partita') {
      const avversario = (document.getElementById('calEventoAvversario').value || '').trim();
      if (!avversario) {
        errorEl.textContent = "Inserisci l'avversario.";
        return;
      }
      payload.avversario = avversario;
      payload.casa_trasferta = document.getElementById('calEventoCasaTrasferta').value;
    } else {
      payload.note = (document.getElementById('calEventoNote').value || '').trim();
    }

    if (eventoId) payload.evento_id = eventoId;

    const { ok, data } = await ajaxPost('usrio_salva_evento', payload);
    if (!ok || !data || data.success === false) {
      errorEl.textContent = `Errore: ${(data && data.data && data.data.errore) || 'richiesta non riuscita'}`;
      return;
    }

    // Per una partita, le convocazioni scelte nello stesso modulo vengono
    // salvate subito dopo, sull'evento appena creato o modificato: un
    // unico passaggio, invece di dover tornare più tardi ad aprire di
    // nuovo l'evento per convocare i giocatori.
    if (tipo === 'partita') {
      const idGiocatori = Array.from(form.querySelectorAll('[data-cal-form-convocati] input[type="checkbox"]:checked')).map((cb) => cb.value);
      const idEventoSalvato = (data.data && data.data.id) || eventoId;
      if (idEventoSalvato) {
        const { ok: convOk } = await ajaxPost('usrio_salva_convocazioni', { evento_id: idEventoSalvato, id_giocatori: idGiocatori });
        if (!convOk) {
          errorEl.textContent = 'Partita salvata, ma le convocazioni non sono state salvate.';
          return;
        }
      }
    }

    calendarFormAperto = null;
    calendarEventoInModifica = null;
    await loadCalendarMese();
  });

  // ---- Avvio ----
  const oggi = new Date();
  calendarAnno = oggi.getFullYear();
  calendarMese = oggi.getMonth() + 1;

  (async () => {
    if (!calendarSquadraFissa) {
      await populateCalendarSquadraSelect();
    }
    if (calendarSquadraId) {
      await loadCalendarMese();
    } else {
      wrap.innerHTML = '<p class="loading-note">Nessuna squadra disponibile.</p>';
    }
  })();
});
