// Pannello del Socio in "La Mia Area": squadre, rosa dei giocatori e
// accessi al sito (Giocatore, Allenatore, Iscritto), tutto via AJAX,
// direttamente sul sito — mai un salto a wp-admin. Caricato solo nella
// pagina "area-riservata".

document.addEventListener('DOMContentLoaded', () => {
  if (typeof UsrioAreaRiservataAjax === 'undefined') return;

  const squadreTableEl = document.getElementById('areaSquadreTable');
  const giocatoriSelectEl = document.getElementById('areaGiocatoriSquadraSelect');
  const giocatoriTableEl = document.getElementById('areaGiocatoriTable');
  const utentiTableEl = document.getElementById('areaUtentiTable');

  // Se questi elementi non ci sono, non siamo sul pannello del Socio
  // (siamo su un altro profilo): non c'è altro da fare qui.
  if (!squadreTableEl && !giocatoriTableEl && !utentiTableEl) return;

  let squadre = [];
  let giocatoriRosa = [];
  let giocatoriSquadraId = null;

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function armRemoveButton(btn, onConfirm) {
    if (btn.dataset.armed === 'true') {
      clearTimeout(Number(btn.dataset.armTimer));
      onConfirm();
      return;
    }
    btn.dataset.armed = 'true';
    btn.dataset.originalLabel = btn.textContent;
    btn.textContent = 'Confermi?';
    btn.classList.add('is-armed');
    const timer = setTimeout(() => {
      btn.dataset.armed = 'false';
      btn.textContent = btn.dataset.originalLabel;
      btn.classList.remove('is-armed');
    }, 4000);
    btn.dataset.armTimer = String(timer);
  }

  async function ajaxGet(action, params) {
    const query = new URLSearchParams({ action, nonce: UsrioAreaRiservataAjax.nonce, ...params });
    const res = await fetch(`${UsrioAreaRiservataAjax.url}?${query.toString()}`);
    return res.ok ? res.json() : null;
  }

  async function ajaxPost(action, params) {
    const body = new URLSearchParams({ action, nonce: UsrioAreaRiservataAjax.nonce });
    Object.entries(params || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null) body.append(key, value);
    });
    const res = await fetch(UsrioAreaRiservataAjax.url, { method: 'POST', body });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, data };
  }

  function erroreDi(data, fallback) {
    return (data && data.data && data.data.errore) || fallback || 'richiesta non riuscita';
  }

  function mostraStato(msg, isError) {
    const el = document.getElementById('areaStatus');
    if (!el) return;
    el.textContent = msg;
    el.classList.toggle('is-error', !!isError);
    if (!isError) {
      setTimeout(() => { if (el.textContent === msg) el.textContent = ''; }, 3500);
    }
  }

  // ---- Squadre ----

  async function caricaSquadre() {
    squadre = (await ajaxGet('usrio_area_get_squadre')) || [];
    renderSquadreTable();
    popolaSquadraSelect(giocatoriSelectEl, giocatoriSquadraId);
    popolaSquadraSelect(document.getElementById('utenteSquadraSelect'), null);
  }

  function renderSquadreTable() {
    if (!squadreTableEl) return;
    if (!squadre.length) {
      squadreTableEl.innerHTML = '<p class="loading-note">Nessuna squadra: aggiungine una qui sotto.</p>';
      return;
    }
    squadreTableEl.innerHTML = `
      <table class="table-preview">
        <tr><th>Squadra</th><th></th></tr>
        ${squadre.map((s) => `
          <tr>
            <td>${escapeHtml(s.nome)}</td>
            <td><button type="button" class="btn-remove-row" data-elimina-squadra="${s.id}">Rimuovi</button></td>
          </tr>
        `).join('')}
      </table>
    `;
  }

  function popolaSquadraSelect(sel, valoreAttuale) {
    if (!sel) return;
    if (!squadre.length) {
      sel.innerHTML = '<option value="">Nessuna squadra</option>';
      return;
    }
    sel.innerHTML = squadre.map((s) => `
      <option value="${s.id}" ${String(s.id) === String(valoreAttuale) ? 'selected' : ''}>${escapeHtml(s.nome)}</option>
    `).join('');
  }

  // ---- Rosa dei giocatori ----

  async function caricaGiocatoriRosa() {
    if (!giocatoriTableEl) return;
    if (!giocatoriSquadraId) {
      giocatoriTableEl.innerHTML = '<p class="loading-note">Aggiungi prima una squadra.</p>';
      return;
    }
    giocatoriTableEl.innerHTML = '<p class="loading-note">Caricamento rosa…</p>';
    giocatoriRosa = (await ajaxGet('usrio_area_get_giocatori', { squadra_id: giocatoriSquadraId })) || [];
    renderGiocatoriTable();
  }

  function renderGiocatoriTable() {
    if (!giocatoriRosa.length) {
      giocatoriTableEl.innerHTML = '<p class="loading-note">Nessun giocatore in questa squadra.</p>';
      return;
    }
    giocatoriTableEl.innerHTML = `
      <table class="table-preview">
        <tr><th>Nome</th><th>Ruolo</th><th></th></tr>
        ${giocatoriRosa.map((g) => `
          <tr>
            <td>${escapeHtml(g.nome)} ${escapeHtml(g.cognome || '')}</td>
            <td>${escapeHtml(g.ruolo || '—')}</td>
            <td><button type="button" class="btn-remove-row" data-elimina-giocatore="${g.id}">Rimuovi</button></td>
          </tr>
        `).join('')}
      </table>
    `;
  }

  // ---- Accessi al sito (utenti) ----

  async function caricaUtenti() {
    if (!utentiTableEl) return;
    utentiTableEl.innerHTML = '<p class="loading-note">Caricamento…</p>';
    const utenti = (await ajaxGet('usrio_area_get_utenti')) || [];
    if (!utenti.length) {
      utentiTableEl.innerHTML = '<p class="loading-note">Nessun accesso creato finora.</p>';
      return;
    }
    const etichetteRuolo = { giocatore: 'Giocatore', allenatore: 'Allenatore', iscritto: 'Iscritto' };
    utentiTableEl.innerHTML = `
      <table class="table-preview">
        <tr><th>Nome</th><th>Email</th><th>Profilo</th><th>Collegato a</th><th></th></tr>
        ${utenti.map((u) => `
          <tr>
            <td>${escapeHtml(u.nome)}</td>
            <td>${escapeHtml(u.email)}</td>
            <td>${escapeHtml(etichetteRuolo[u.ruolo] || u.ruolo)}</td>
            <td>${escapeHtml(u.collegamento || '—')}</td>
            <td><button type="button" class="btn-remove-row" data-elimina-utente="${u.id}">Rimuovi</button></td>
          </tr>
        `).join('')}
      </table>
    `;
  }

  async function popolaGiocatoreSelectPerUtente() {
    const sel = document.getElementById('utenteGiocatoreSelect');
    if (!sel) return;
    const tutti = (await ajaxGet('usrio_area_get_giocatori')) || [];
    if (!tutti.length) {
      sel.innerHTML = '<option value="">Nessun giocatore in rosa</option>';
      return;
    }
    sel.innerHTML = tutti.map((g) => `
      <option value="${g.id}">${escapeHtml(g.nome)} ${escapeHtml(g.cognome || '')} — ${escapeHtml(g.squadra_nome || 'nessuna squadra')}</option>
    `).join('');
  }

  // ---- Eventi ----

  document.addEventListener('change', (e) => {
    if (e.target.id === 'areaGiocatoriSquadraSelect') {
      giocatoriSquadraId = e.target.value;
      caricaGiocatoriRosa();
      return;
    }
    if (e.target.id === 'utenteRuolo') {
      const gruppoSquadra = document.getElementById('utenteSquadraGroup');
      const gruppoGiocatore = document.getElementById('utenteGiocatoreGroup');
      const ruolo = e.target.value;
      if (gruppoSquadra) gruppoSquadra.hidden = ruolo !== 'allenatore';
      if (gruppoGiocatore) {
        gruppoGiocatore.hidden = ruolo !== 'giocatore';
        if (ruolo === 'giocatore') popolaGiocatoreSelectPerUtente();
      }
    }
  });

  document.addEventListener('click', (e) => {
    const eliminaSquadra = e.target.closest('[data-elimina-squadra]');
    if (eliminaSquadra) {
      armRemoveButton(eliminaSquadra, async () => {
        const { ok, data } = await ajaxPost('usrio_area_elimina_squadra', { squadra_id: eliminaSquadra.dataset.eliminaSquadra });
        if (!ok) { mostraStato(`Errore: ${erroreDi(data)}`, true); return; }
        mostraStato('Squadra rimossa.');
        await caricaSquadre();
      });
      return;
    }

    const eliminaGioc = e.target.closest('[data-elimina-giocatore]');
    if (eliminaGioc) {
      armRemoveButton(eliminaGioc, async () => {
        const { ok, data } = await ajaxPost('usrio_area_elimina_giocatore', { giocatore_id: eliminaGioc.dataset.eliminaGiocatore });
        if (!ok) { mostraStato(`Errore: ${erroreDi(data)}`, true); return; }
        mostraStato('Giocatore rimosso.');
        await caricaGiocatoriRosa();
      });
      return;
    }

    const eliminaUtente = e.target.closest('[data-elimina-utente]');
    if (eliminaUtente) {
      armRemoveButton(eliminaUtente, async () => {
        const { ok, data } = await ajaxPost('usrio_area_elimina_utente', { utente_id: eliminaUtente.dataset.eliminaUtente });
        if (!ok) { mostraStato(`Errore: ${erroreDi(data)}`, true); return; }
        mostraStato('Accesso rimosso.');
        await caricaUtenti();
      });
    }
  });

  document.addEventListener('submit', async (e) => {
    if (e.target.id === 'areaSalvaSquadraForm') {
      e.preventDefault();
      const errorEl = document.getElementById('areaSquadraError');
      const nome = (document.getElementById('areaSquadraNome').value || '').trim();
      errorEl.textContent = '';
      if (!nome) { errorEl.textContent = 'Inserisci il nome della squadra.'; return; }
      const { ok, data } = await ajaxPost('usrio_area_salva_squadra', { nome });
      if (!ok) { errorEl.textContent = `Errore: ${erroreDi(data)}`; return; }
      e.target.reset();
      await caricaSquadre();
      return;
    }

    if (e.target.id === 'areaSalvaGiocatoreForm') {
      e.preventDefault();
      const errorEl = document.getElementById('areaGiocError');
      errorEl.textContent = '';
      const nome = (document.getElementById('areaGiocNome').value || '').trim();
      const cognome = (document.getElementById('areaGiocCognome').value || '').trim();
      const ruolo = (document.getElementById('areaGiocRuolo').value || '').trim();
      if (!giocatoriSquadraId) { errorEl.textContent = 'Scegli prima una squadra.'; return; }
      if (!nome || !cognome) { errorEl.textContent = 'Inserisci nome e cognome del giocatore.'; return; }
      const { ok, data } = await ajaxPost('usrio_area_salva_giocatore', { nome, cognome, ruolo, squadra_id: giocatoriSquadraId });
      if (!ok) { errorEl.textContent = `Errore: ${erroreDi(data)}`; return; }
      e.target.reset();
      await caricaGiocatoriRosa();
      return;
    }

    if (e.target.id === 'areaCreaUtenteForm') {
      e.preventDefault();
      const errorEl = document.getElementById('areaUtenteError');
      errorEl.textContent = '';
      const nome = (document.getElementById('utenteNome').value || '').trim();
      const cognome = (document.getElementById('utenteCognome').value || '').trim();
      const email = (document.getElementById('utenteEmail').value || '').trim();
      const ruolo = document.getElementById('utenteRuolo').value;
      const squadraId = document.getElementById('utenteSquadraSelect') ? document.getElementById('utenteSquadraSelect').value : '';
      const giocatoreId = document.getElementById('utenteGiocatoreSelect') ? document.getElementById('utenteGiocatoreSelect').value : '';

      if (!nome || !cognome || !email || !ruolo) {
        errorEl.textContent = 'Nome, cognome, email e profilo sono obbligatori.';
        return;
      }
      if (ruolo === 'allenatore' && !squadraId) {
        errorEl.textContent = "Scegli la squadra da assegnare all'Allenatore.";
        return;
      }

      const { ok, data } = await ajaxPost('usrio_area_crea_utente', {
        nome, cognome, email, ruolo,
        squadra_id: ruolo === 'allenatore' ? squadraId : '',
        giocatore_id: ruolo === 'giocatore' ? giocatoreId : '',
      });
      if (!ok) { errorEl.textContent = `Errore: ${erroreDi(data)}`; return; }
      e.target.reset();
      document.getElementById('utenteSquadraGroup').hidden = true;
      document.getElementById('utenteGiocatoreGroup').hidden = true;
      await caricaUtenti();
    }
  });

  // ---- Avvio ----
  (async () => {
    await caricaSquadre();
    if (squadre.length) {
      giocatoriSquadraId = squadre[0].id;
      if (giocatoriSelectEl) giocatoriSelectEl.value = giocatoriSquadraId;
      await caricaGiocatoriRosa();
    }
    await caricaUtenti();
  })();
});
