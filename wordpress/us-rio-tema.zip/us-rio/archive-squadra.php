<?php
/**
 * Elenco delle Squadre: prima pagina "pubblica" davvero collegata al
 * database di WordPress. Il Socio aggiunge/toglie le squadre dal pannello
 * di amministrazione (Squadre → Aggiungi nuova), esattamente come farebbe
 * con un Articolo.
 */
get_header();
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Il club</p>
		<h1>Squadre</h1>
		<p class="view-sub">Le categorie della società, dal settore giovanile alla prima squadra.</p>
	</div>
	<div class="showcase-grid">
		<?php if ( have_posts() ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<div class="showcase-card" data-href="<?php echo esc_url( get_permalink() ); ?>">
					<div class="thumb thumb-chibi"><?php usrio_icon_photo(); ?></div>
					<div class="body">
						<span class="name"><?php the_title(); ?></span>
						<span class="desc">Rosa e informazioni della categoria.</span>
					</div>
				</div>
			<?php endwhile; ?>
		<?php else : ?>
			<p class="loading-note">Nessuna squadra ancora inserita. Il Socio può aggiungerne una da "Squadre → Aggiungi nuova" nel pannello di amministrazione.</p>
		<?php endif; ?>
	</div>
</div>
<?php get_footer(); ?>
