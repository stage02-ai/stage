<?php
/** Template: pagina "Società" (slug: societa) */
get_header();
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">Il club</p>
		<h1>Società</h1>
		<p class="view-sub">Chi è U.S. Rio A.S.D., e il suo legame con il Calcio Padova.</p>
	</div>
	<div class="prose">
		<p>U.S. Rio A.S.D. è affiliata al Calcio Padova, con cui collabora nell'ambito del settore giovanile.</p>
	</div>
	<div class="photo-slot photo-slot-chibi">
		<div class="hero-photo-row"><?php usrio_icon_photo(); ?></div>
		<span>Foto sede/dirigenza in arrivo</span>
	</div>
	<div class="placeholder-card">
		<strong>🚧 Testo segnaposto.</strong> Questa sezione andrà completata con i contenuti reali forniti dalla società: descrizione ufficiale, dettagli dell'affiliazione con il Calcio Padova (settore giovanile, scuola calcio, collaborazione tecnica), organigramma/dirigenza e sede sociale.
	</div>

	<div class="sub-menu">
		<p class="sub-menu-label">Vedi anche</p>
		<div class="showcase-grid">
			<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/storia/' ) ); ?>">
				<div class="thumb"><?php usrio_icon_photo(); ?></div>
				<div class="body">
					<span class="name">Storia</span>
					<span class="desc">Le tappe principali della storia del club.</span>
				</div>
			</div>
			<div class="showcase-card" data-href="<?php echo esc_url( home_url( '/sponsor/' ) ); ?>">
				<div class="thumb"><?php usrio_icon_photo(); ?></div>
				<div class="body">
					<span class="name">Sponsor</span>
					<span class="desc">Le aziende che sostengono U.S. Rio A.S.D.</span>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
