<?php
/**
 * Bacheca della squadra (slug: bacheca-squadra): calendario mensile di
 * partite (rosse) e allenamenti (blu). Tutto avviene qui, sul sito: la
 * pagina carica gli eventi via AJAX e l'Allenatore aggiunge, modifica ed
 * elimina partite/allenamenti (e imposta le convocazioni) senza mai
 * passare da wp-admin — lo script js/bacheca-calendario.js fa tutto il
 * lavoro, con gli stessi endpoint AJAX registrati in functions.php.
 * Giocatore e Socio guardano soltanto, scegliendo la squadra da un elenco.
 */
get_header();

if ( ! is_user_logged_in() ) {
	echo '<div class="view-inner"><div class="placeholder-card"><strong>🚧 Area riservata.</strong> Effettua l\'accesso per vedere questa pagina.</div></div>';
	get_footer();
	return;
}

$user     = wp_get_current_user();
$role     = ! empty( $user->roles ) ? $user->roles[0] : '';
$can_edit      = false; // può aggiungere/modificare/eliminare eventi e convocazioni
$squadra_fissa = false; // vero se la squadra è quella propria: niente elenco da cui sceglierne un'altra
$squadra_id    = 0;
$squadra_nome  = '';

if ( 'allenatore' === $role ) {
	$squadra_assegnata = get_field( 'squadra_assegnata', 'user_' . $user->ID );
	if ( ! $squadra_assegnata ) {
		?>
		<div class="view-inner">
			<div class="view-header">
				<p class="eyebrow">La Mia Area &rsaquo; Bacheca Squadra</p>
				<h1>Bacheca Squadra</h1>
			</div>
			<div class="placeholder-card">
				<strong>🚧 Nessuna squadra assegnata.</strong> Il Socio non ti ha ancora assegnato una squadra dal tuo profilo utente. Chiedigli di farlo da Utenti &rsaquo; il tuo profilo &rsaquo; "Squadra assegnata".
			</div>
		</div>
		<?php
		get_footer();
		return;
	}
	$squadra_id    = $squadra_assegnata->ID;
	$squadra_nome  = $squadra_assegnata->post_title;
	$can_edit      = true;
	$squadra_fissa = true;
} elseif ( 'giocatore' === $role ) {
	// La squadra vera viene riconosciuta dal collegamento che il Socio ha
	// impostato sul profilo (Giocatore collegato): mai un elenco da cui
	// scegliere, altrimenti il giocatore vedrebbe anche le bacheche di
	// squadre che non sono la sua.
	$giocatore_collegato = get_field( 'giocatore_collegato', 'user_' . $user->ID );
	$squadra_del_giocatore = $giocatore_collegato ? get_field( 'squadra', $giocatore_collegato->ID ) : null;
	if ( ! $squadra_del_giocatore ) {
		?>
		<div class="view-inner">
			<div class="view-header">
				<p class="eyebrow">La Mia Area &rsaquo; Bacheca Squadra</p>
				<h1>Bacheca Squadra</h1>
			</div>
			<div class="placeholder-card">
				<strong>🚧 Nessuna squadra assegnata.</strong> Il Socio non ti ha ancora collegato il tuo accesso a una riga della rosa. Chiedigli di farlo da Utenti &rsaquo; il tuo profilo &rsaquo; "Giocatore collegato".
			</div>
		</div>
		<?php
		get_footer();
		return;
	}
	$squadra_id    = $squadra_del_giocatore->ID;
	$squadra_nome  = $squadra_del_giocatore->post_title;
	$squadra_fissa = true;
} elseif ( 'socio' === $role ) {
	// Il Socio deve poter controllare tutte le squadre (elenco), e gestire
	// gli eventi di ciascuna: gli serve anche per correggere o togliere un
	// evento sbagliato quando una squadra non ha un responsabile che se ne
	// occupi.
	$can_edit = true;
}
?>
<div class="view-inner">
	<div class="view-header">
		<p class="eyebrow">La Mia Area &rsaquo; <?php echo esc_html( $squadra_fissa ? $squadra_nome : 'Bacheca Squadra' ); ?></p>
		<h1><?php echo $squadra_fissa ? 'Bacheca &mdash; ' . esc_html( $squadra_nome ) : 'Bacheca Squadra'; ?></h1>
		<p class="view-sub">
			<?php if ( $squadra_fissa ) : ?>
				Calendario di partite e allenamenti della squadra <?php echo esc_html( $squadra_nome ); ?>.
			<?php else : ?>
				Scegli una squadra per vedere<?php echo $can_edit ? ', aggiungere o correggere' : ''; ?> partite, allenamenti e convocazioni.
			<?php endif; ?>
		</p>
	</div>

	<?php if ( ! $squadra_fissa ) : ?>
		<label class="form-group cal-team-picker">
			<span>Squadra</span>
			<select id="calendarSquadraSelect"></select>
		</label>
	<?php endif; ?>
	<?php if ( $can_edit ) : ?>
		<p class="admin-status" id="calStatus"></p>
	<?php endif; ?>

	<div class="cal-wrap" id="calendarWrap">
		<p class="loading-note">Caricamento calendario…</p>
	</div>
</div>
<script>
	window.UsrioCalendarioInit = {
		puoModificare: <?php echo $can_edit ? 'true' : 'false'; ?>,
		squadraFissa: <?php echo $squadra_fissa ? 'true' : 'false'; ?>,
		squadraId: <?php echo (int) $squadra_id; ?>,
		squadraNome: <?php echo wp_json_encode( $squadra_nome ); ?>
	};
</script>
<?php get_footer(); ?>
